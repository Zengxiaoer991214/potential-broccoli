create table memo
(
    id   int auto_increment
        primary key,
    time text null,
    list text null
);

INSERT INTO wx.memo (id, time, list) VALUES (0, '2021/04/20 10:17:02pm', '["高等数学","英语四级","英语单词","英语语法","日常编程"]');