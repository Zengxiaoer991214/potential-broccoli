create table user_info
(
    u_i_id          int(8) auto_increment
        primary key,
    u_i_openid      text          not null comment '标识用户身份',
    u_i_session_key text          not null comment '密码',
    integral        int default 0 null
)
    charset = utf8mb4;

INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (1, 'oq9-q5YX2yGw0BKNFOnsQjICJyAU', '8eY6di+1vecsA7odpp8S1w==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (2, 'oq9-q5TKxekuv6nq3qsOAfFY8vOg', 'K2oiKqZQSCg4PzZRrHYy0A==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (3, 'oq9-q5XuucW8NiPVLqPaT8u6YgQ8', 'lWyn9A2ka1M9cczJuTR04A==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (4, 'oq9-q5QchBh8OHevUT1PU4sUg_DA', 'qzzbYjtpJMO+uAat26477Q==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (5, 'oq9-q5XZeBof-2clFu6GCIFDUeP4', '4Hxb8HBCWH50qJmhKfOHHA==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (6, 'oq9-q5fYlXaycwYnupPDvGceSN38', 'hOMCExvbaHZaGLuKsqrGbA==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (7, 'oq9-q5d63ABDyqZzfCOAL-cN-I_w', 'xW9Xs1pRPwN/lmrQqvLyHg==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (8, 'oq9-q5fWrAOK12qkf-mIN9dPtSMc', 'sQmN84J/rwW0BblxHdinXA==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (9, 'oq9-q5ZbI8lLJCkutq8fTh_KQNeA', 'Y4FKR2MY6b+BRGY7e71rtg==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (10, 'oq9-q5UvAvaPQFpOFZVyWP4IAXdw', 'hLwLx2L17coZr7iAV61L/g==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (11, 'oq9-q5cA7ysKiP4vP5x9A1tLxaBI', 'pZoxL1zSg4bNYg3lY1eVRA==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (12, 'oq9-q5eowx3YYnV48i-MxW9b9m04', 'A9GKQk4LPemcCg8qKtl7vg==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (13, 'oq9-q5XiPVcZPwtY6EVGzHSpfpro', '95WB3XYSaXZe9objx/4Bcg==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (14, 'oq9-q5e3dlx4mwQ72pgQ-Elgz3qg', 'zS3Dj3wuw0MmMvsUMyOizw==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (15, 'oq9-q5ZPpQwTW7XD5Dxe6PQidA94', 'GNm0ZPAhXzddVZXfw0RWbQ==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (16, 'oq9-q5aXpBCfSGMITx5P3ffC2oB4', 'Z/Akyu2VBDOWMa6dA5gRUQ==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (17, 'oq9-q5UrWTldagpyQ6U21rFIPftI', '4JC8j/ZBRpmi9Z2UAcBRDQ==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (18, 'oq9-q5a8KSj4Qm2R5qmcRTtLVQ58', 'FE8fOXjAqmHyggRFjAxjOQ==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (19, 'oq9-q5THDtlSQ_j-1CFB2LN9KC8E', 'IpjdbRPGBfBVhdSdtGpp2Q==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (20, 'oq9-q5ZgeezPC8bNGkE7clxhjHyM', 'fmpgJEHoTQhFWvdCEOOjlg==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (21, 'oq9-q5ZgeezPC8bNGkE7clxhjHyM', 'fmpgJEHoTQhFWvdCEOOjlg==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (22, 'oq9-q5V5JYI2COy5rGGjC2lm8nrQ', 'Qo0rAtR8tfYJ3rqcbM2YOg==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (23, 'oq9-q5aqMZICopIDO9pwTNEXDa6k', 'musmLYrS5hFCx40dF9EeBg==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (24, 'oq9-q5bKIgwhb1VCk2NfTl_8qaa8', 'ExQ8XsbJbkAcgPgrtNt1Vg==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (25, 'oq9-q5V3v3ZXQOsEOVsECd-T4IUQ', '+9Yj+jGXtJNDjbwWFzDA+Q==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (26, 'oq9-q5UagXeGlRnR-CYKkiIx-iVM', 'uhxsTOwg+37SEwiZpPaa6g==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (27, 'oq9-q5RcFcTUNF8TW6NS3k-PltcE', 'YAsVMTaz/3WWcBya8NmHFw==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (28, 'oq9-q5axB5HRWbzb0jR41U8-TJI8', 'TDSjpudOw2gDpvsLb/Yofw==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (29, 'oq9-q5Ri5G84cD8zjQKTtVR1ztZU', 'pumBALoM44QAfJdo70y7DQ==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (30, 'oq9-q5UQYPbdZQFOeEwiXPeoxHfw', 'EmLey/4KcYnJWCe5Nhh9ag==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (31, 'oq9-q5Rl0p5IVs8VHhv1pE-VqP34', 'c2N4vEGKDxhix+KKlnOGnw==', 0);
INSERT INTO wx.user_info (u_i_id, u_i_openid, u_i_session_key, integral) VALUES (32, 'oq9-q5WN6dieb4rwwz-A6asJhLJU', 'BNlVYSpT7vpaK5YRIcagqw==', 0);