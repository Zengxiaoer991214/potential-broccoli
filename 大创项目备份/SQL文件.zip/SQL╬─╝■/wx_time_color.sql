create table time_color
(
    t_c_id    int(4) auto_increment
        primary key,
    t_c_color text not null,
    t_c_hex   text null,
    t_c_name  text null
)
    charset = utf8mb4;

INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (90, 'rgb(145, 61, 136)', '#913D88', 'Plum');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (91, 'rgb(154, 18, 179)', '#9A12B3', 'Seance');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (92, 'rgb(191, 85, 236)', '#BF55EC', 'Medium Purple');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (93, 'rgb(190, 144, 212)', '#BE90D4', 'Light Wisteria');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (94, 'rgb(142, 68, 173)', '#8E44AD', 'Studio');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (95, 'rgb(155, 89, 182)', '#9B59B6', 'Wisteria');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (96, 'rgb(224, 130, 131)', '#E08283', 'New York Pink');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (97, 'rgb(242, 38, 19)', '#F22613', 'Pomegranate');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (98, 'rgb(255, 0, 0)', '#FF0000', 'Red');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (99, 'rgb(226, 106, 106)', '#E26A6A', 'Sunglo');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (100, 'rgb(217, 30, 24)', '#D91E18', 'Thunderbird');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (101, 'rgb(150, 40, 27)', '#96281B', 'Old Brick');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (102, 'rgb(239, 72, 54)', '#EF4836', 'Flamingo');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (103, 'rgb(214, 69, 65)', '#D64541', 'Valencia');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (104, 'rgb(192, 57, 43)', '#C0392B', 'Tall Poppy');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (105, 'rgb(207, 0, 15)', '#CF000F', 'Monza');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (106, 'rgb(231, 76, 60)', '#E74C3C', 'Cinnabar');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (107, 'rgb(232, 126, 4)', '#E87E04', 'Tahiti Gold');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (108, 'rgb(244, 179, 80)', '#F4B350', 'Casablanca');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (109, 'rgb(242, 120, 75)', '#F2784B', 'Crusta');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (110, 'rgb(235, 151, 78)', '#EB974E', 'Jaffa');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (111, 'rgb(245, 171, 53)', '#F5AB35', 'Lightning Yellow');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (112, 'rgb(244, 208, 63)', '#F4D03F', 'Saffron');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (113, 'rgb(211, 84, 0)', '#D35400', 'Burnt Orange');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (114, 'rgb(243, 156, 18)', '#F39C12', 'Buttercup');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (115, 'rgb(249, 105, 14)', '#F9690E', 'Ecstasy');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (116, 'rgb(247, 202, 24)', '#F7CA18', 'Ripe Lemon');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (117, 'rgb(249, 191, 59)', '#F9BF3B', 'Saffron');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (118, 'rgb(242, 121, 53)', '#F27935', 'Jaffa');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (119, 'rgb(230, 126, 34)', '#E67E22', 'Zest');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (120, 'rgb(235, 149, 50)', '#EB9532', 'Fire Bush');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (121, 'rgb(210, 215, 211)', '#D2D7D3', 'Pumice');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (122, 'rgb(238, 238, 238)', '#EEEEEE', 'Gallery');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (123, 'rgb(189, 195, 199)', '#BDC3C7', 'Silver Sand');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (124, 'rgb(236, 240, 241)', '#ECF0F1', 'Porcelain');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (125, 'rgb(149, 165, 166)', '#95A5A6', 'Cascade');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (126, 'rgb(218, 223, 225)', '#DADFE1', 'Iron');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (127, 'rgb(171, 183, 183)', '#ABB7B7', 'Edward');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (128, 'rgb(191, 191, 191)', '#BFBFBF', 'Silver');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (129, 'rgb(101, 198, 187)', '#65C6BB', 'Downy');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (130, 'rgb(27, 188, 155)', '#1BBC9B', 'Mountain Meadow');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (131, 'rgb(27, 163, 156)', '#1BA39C', 'Light Sea Green');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (132, 'rgb(102, 204, 153)', '#66CC99', 'Medium Aquamarine');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (133, 'rgb(54, 215, 183)', '#36D7B7', 'Turquoise');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (134, 'rgb(4, 147, 114)', '#049372', 'Observatory');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (135, 'rgb(200, 247, 197)', '#C8F7C5', 'Madang');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (136, 'rgb(134, 226, 213)', '#86E2D5', 'Riptide');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (137, 'rgb(46, 204, 113)', '#2ECC71', 'Shamrock');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (138, 'rgb(22, 160, 133)', '#16a085', 'Mountain Meadow');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (139, 'rgb(63, 195, 128)', '#3FC380', 'Emerald');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (140, 'rgb(1, 152, 117)', '#019875', 'Green Haze');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (141, 'rgb(38, 194, 129)', '#26C281', 'Jungle Green');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (142, 'rgb(3, 166, 120)', '#03A678', 'Free Speech Aquamarine');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (143, 'rgb(77, 175, 124)', '#4DAF7C', 'Ocean Green');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (144, 'rgb(42, 187, 155)', '#2ABB9B', 'Jungle Green');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (145, 'rgb(0, 177, 106)', '#00B16A', 'Jade');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (146, 'rgb(30, 130, 76)', '#1E824C', 'Salem');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (147, 'rgb(38, 166, 91)', '#26A65B', 'Eucalyptus');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (148, 'rgb(89, 171, 227)', '#59ABE3', 'Picton Blue');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (149, 'rgb(82, 179, 217)', '#52B3D9', 'Shakespeare');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (150, 'rgb(34, 167, 240)', '#22A7F0', 'Picton Blue');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (151, 'rgb(52, 152, 219)', '#3498DB', 'Curious Blue');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (152, 'rgb(44, 62, 80)', '#2C3E50', 'Madison');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (153, 'rgb(137, 196, 244)', '#89C4F4', 'Jordy Blue');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (154, 'rgb(25, 181, 254)', '#19B5FE', 'Dodger Blue');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (155, 'rgb(51, 110, 123)', '#336E7B', 'Ming');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (156, 'rgb(34, 49, 63)', '#22313F', 'Ebony Clay');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (157, 'rgb(107, 185, 240)', '#6BB9F0', 'Malibu');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (158, 'rgb(30, 139, 195)', '#1E8BC3', 'Curious Blue');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (159, 'rgb(58, 83, 155)', '#3A539B', 'Chambray');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (160, 'rgb(52, 73, 94)', '#34495E', 'Pickled Bluewood');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (161, 'rgb(103, 128, 159)', '#67809F', 'Hoki');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (162, 'rgb(37, 116, 169)', '#2574A9', 'Jelly Bean');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (163, 'rgb(31, 58, 147)', '#1F3A93', 'Jacksons Purple');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (164, 'rgb(75, 119, 190)', '#4B77BE', 'Steel Blue');
INSERT INTO wx.time_color (t_c_id, t_c_color, t_c_hex, t_c_name) VALUES (165, 'rgb(92, 151, 191)', '#5C97BF', 'Fountain Blue');