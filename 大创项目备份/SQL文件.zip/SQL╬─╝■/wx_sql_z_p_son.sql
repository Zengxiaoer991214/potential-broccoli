create table p_son
(
    p_s_id   int auto_increment
        primary key,
    p_s_name text null,
    p_s_son  text null
);

INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (2, '金融', '38<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (3, '应用统计', '39<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (4, '税务', '40<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (5, '国际商务', '41<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (6, '保险', '42<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (7, '资产评估', '43<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (8, '审计', '44<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (9, '法律', '45<<46<<47<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (10, '社会工作', '48<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (11, '警务', '49<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (12, '教育', '50<<51<<52<<53<<54<<55<<56<<57<<58<<59<<60<<61<<62<<63<<64<<65<<66<<67<<68<<69<<70<<71<<72<<73<<74<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (13, '体育', '75<<76<<77<<78<<79<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (14, '汉语国际教育', '80<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (15, '应用心理', '81<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (16, '翻译', '82<<83<<84<<85<<86<<87<<88<<89<<90<<91<<92<<93<<94<<95<<96<<97<<98<<99<<100<<101<<102<<103<<104<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (17, '新闻与传播', '105<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (18, '出版', '106<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (19, '文物与博物馆', '107<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (20, '建筑学', '108<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (21, '城市规划', '109<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (22, '电子信息', '110<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (23, '机械', '111<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (24, '材料与化工', '112<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (25, '资源与环境', '113<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (26, '能源动力', '114<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (27, '土木水利', '115<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (28, '生物与医药', '116<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (29, '交通运输', '117<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (30, '农业', '118<<119<<120<<121<<122<<123<<124<<125<<126<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (31, '兽医', '127<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (32, '风景园林', '128<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (33, '林业', '129<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (34, '临床医学', '130<<131<<132<<133<<134<<135<<136<<137<<138<<139<<140<<141<<142<<143<<144<<145<<146<<147<<148<<149<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (35, '口腔医学', '150<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (36, '公共卫生', '151<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (37, '护理', '152<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (38, '药学', '153<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (39, '中药学', '154<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (40, '中医', '155<<156<<157<<158<<159<<160<<161<<162<<163<<164<<165<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (41, '军事', '166<<167<<168<<169<<170<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (42, '工商管理', '171<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (43, '公共管理', '172<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (44, '会计', '173<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (45, '旅游管理', '174<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (46, '图书情报', '175<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (47, '工程管理', '176<<177<<178<<179<<180<<');
INSERT INTO wx_sql_z.p_son (p_s_id, p_s_name, p_s_son) VALUES (48, '艺术', '181<<182<<183<<184<<185<<186<<187<<188<<189<<');