create table share
(
    id      int auto_increment
        primary key,
    usr_id  int  null,
    label1  text null,
    label2  text null,
    label3  text null,
    date    text null,
    title   text null,
    context text null,
    text    text null
);

INSERT INTO wx.share (id, usr_id, label1, label2, label3, date, title, context, text) VALUES (1, 1, '沈阳理工大学', '', '数学3', '2020/10/17 22:20:00', null, '<p>全新柏林吉他，没用过联系方式:177 7777 7777<p>', '全新柏林吉他，没用过联系方式:177 7777 7777');
INSERT INTO wx.share (id, usr_id, label1, label2, label3, date, title, context, text) VALUES (2, 1, '沈阳理工大学', '', '数学3', '2020/10/17 22:20:00', '', '<p>全新柏林吉他，没用过联系方式:177 7777 7777<p>', '全新柏林吉他，没用过联系方式:177 7777 7777');
INSERT INTO wx.share (id, usr_id, label1, label2, label3, date, title, context, text) VALUES (3, 1, '沈阳理工大学', '', '数学3', '2020/10/17 22:20:00', 'test', '<p>全新柏林吉他，没用过联系方式:177 7777 7777<p>', '全新柏林吉他，没用过联系方式:177 7777 7777');
INSERT INTO wx.share (id, usr_id, label1, label2, label3, date, title, context, text) VALUES (4, 1, '沈阳理工大学', '', '数学3', '2020/10/17 22: 20: 00', 'test', '<p>全新柏林吉他，没用过联系方式: 177 7777 7777<p>', '全新柏林吉他，没用过联系方式: 177 7777 7777');
INSERT INTO wx.share (id, usr_id, label1, label2, label3, date, title, context, text) VALUES (5, 1, '沈阳理工大学', '数学1', '数学3', '2020/10/17 22:20:00', 'test', '<p>全新柏林吉他，没用过联系方式:177 7777 7777<p>', '全新柏林吉他，没用过联系方式:177 7777 7777');