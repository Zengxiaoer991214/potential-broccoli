create table word
(
    id   int auto_increment
        primary key,
    mess text null,
    date text null
);

INSERT INTO wx.word (id, mess, date) VALUES (17, '{"english":"remote","chinese":["adj.((时间，距离)遥远的,偏僻的)","adj.((关系)疏远的，远离的，冷淡的)","adj.(极不相同的,相差很大的)","",""]}', '2021-03-29 08:19:41pm');
INSERT INTO wx.word (id, mess, date) VALUES (18, '{"english":"remove","chinese":["v.(搬迁，移动)","v.(移开，挪走)","v.(去掉，消除；脱去(衣服等))","",""]}', '2021-03-29 08:21:13pm');
INSERT INTO wx.word (id, mess, date) VALUES (19, '{"english":"removal","chinese":["n.(移动，迁居)","n.(除去，切除)","n.(免职，开除)","",""]}', '2021-03-29 08:22:21pm');
INSERT INTO wx.word (id, mess, date) VALUES (20, '{"english":"remain","chinese":["v.(剩下，余留)","v.(留待，尚需)","v.(依然是，依旧是，保持不变)","",""]}', '2021-03-29 08:23:58pm');
INSERT INTO wx.word (id, mess, date) VALUES (28, '{"english":"remainder","chinese":["n.(剩余物，剩余时间，残余部分；其他人员)","n.(余数，余项，差数)","","",""]}', '2021-03-29 08:26:20pm');
INSERT INTO wx.word (id, mess, date) VALUES (29, '{"english":"remains","chinese":["n.(残余(物)；遗迹，废墟；遗体)","","","",""]}', '2021-03-29 08:27:13pm');
INSERT INTO wx.word (id, mess, date) VALUES (30, '{"english":"remember","chinese":["v.(记得，回想起，不忘记)","v.(代……问候；向……送礼)","","",""]}', '2021-03-29 08:28:55pm');
INSERT INTO wx.word (id, mess, date) VALUES (31, '{"english":"remind","chinese":["vt.(提醒，使想起)","","","",""]}', '2021-03-29 08:29:19pm');
INSERT INTO wx.word (id, mess, date) VALUES (32, '{"english":"render","chinese":["v.(使得，使成为)","v.(给予，回报)","v.(提出，呈报)","",""]}', '2021-03-29 08:30:35pm');
INSERT INTO wx.word (id, mess, date) VALUES (33, '{"english":"contemporary","chinese":["adj.(同时代，同时发生的)","adj.(现代的，当代的)","n.(同代人，(几乎)同年龄的人)","",""]}', '2021-03-29 08:32:28pm');
INSERT INTO wx.word (id, mess, date) VALUES (34, '{"english":"contempt","chinese":["n.(轻视，轻蔑)","n.((对规则,危险等的)蔑视，毫不畏惧)","","",""]}', '2021-03-29 08:33:32pm');
INSERT INTO wx.word (id, mess, date) VALUES (35, '{"english":"content","chinese":["n.(容量，含量)","n.(内容，目录)","n.((单数)(书，文章，讲话，计划等的)主题，要旨)","n.((网站上的)信息内容)","adj.(满意的，满足的，惬意的)"]}', '2021-03-29 08:38:20pm');
INSERT INTO wx.word (id, mess, date) VALUES (36, '{"english":"contend","chinese":["v.(竞争，争夺)","v.(声称，主张)","","",""]}', '2021-03-29 08:39:33pm');
INSERT INTO wx.word (id, mess, date) VALUES (37, '{"english":"contest","chinese":["n.(竞赛，比赛(控制权或权力的)竞争，争夺)","v.(争夺，竞争，争论，就……提出异议)","","",""]}', '2021-03-29 08:41:42pm');
INSERT INTO wx.word (id, mess, date) VALUES (38, '{"english":"context","chinese":["n.(上下文，语境)","n.((事件发生的)环境，背景)","","",""]}', '2021-03-29 08:42:49pm');
INSERT INTO wx.word (id, mess, date) VALUES (39, '{"english":"contract","chinese":["n.(<律>合同，契约)","v.(缩小，缩短，缩紧)","v.(立约规定(或雇佣，承担，执行等))","v.(<医>感染(疾病)，患(病))",""]}', '2021-03-29 08:45:27pm');
INSERT INTO wx.word (id, mess, date) VALUES (40, '{"english":"contradict","chinese":["v.(反驳；同……相矛盾)","","","",""]}', '2021-03-29 08:46:11pm');
INSERT INTO wx.word (id, mess, date) VALUES (41, '{"english":"contrary","chinese":["adj.(相反的，对抗的；好与人作对的)","n.(［常作 the ~］相反事物，反对，对立面)","","",""]}', '2021-03-29 08:48:06pm');
INSERT INTO wx.word (id, mess, date) VALUES (42, '{"english":"contrast","chinese":["v.(［宾语后有时跟with或and］使成对比，使成对照)","v.(形成对比，显出明显的差异(with))","n.(对照，对比)","n.(差异，差别)","n.(明显不同的人(或事物))"]}', '2021-03-29 08:52:43pm');
INSERT INTO wx.word (id, mess, date) VALUES (44, '{"english":"diverse","chinese":["adj.(多种多样的，不同的)","","","",""]}', '2021-03-30 09:05:51pm');
INSERT INTO wx.word (id, mess, date) VALUES (46, '{"english":"diversion","chinese":["n.(转向，转移)","n.(转移注意力的事物)","n.(娱乐，消遣)","",""]}', '2021-03-30 09:07:24pm');
INSERT INTO wx.word (id, mess, date) VALUES (51, '{"english":"divert","chinese":["v.(转移(某人的)注意力；(使)转向)","v.(改变(资金，材料等)的用途，挪用资金，盗用)","v.(使(某人)得到消遣或娱乐)","",""]}', '2021-03-30 09:10:02pm');
INSERT INTO wx.word (id, mess, date) VALUES (56, '{"english":"divide","chinese":["v.(分，划分；分裂)","v.(分配，分享，分担)","v.(分开，隔开，除)","n.(差异,分歧，不同)","n.((时间，过程的)分界线，分界点)"]}', '2021-03-30 09:13:43pm');
INSERT INTO wx.word (id, mess, date) VALUES (57, '{"english":"dividend","chinese":["n.(股息，红利，报酬)","n.(被除数)","","",""]}', '2021-03-30 09:14:52pm');
INSERT INTO wx.word (id, mess, date) VALUES (58, '{"english":"division","chinese":["n.(分开，分配)","n.(部门(科，处，系等))","n.(差异，分歧)","n.(除法)",""]}', '2021-03-30 09:16:15pm');
INSERT INTO wx.word (id, mess, date) VALUES (59, '{"english":"document","chinese":["n.(公文，文件，文献，(计算机)文档)","v.(记录，记载(详情))","","",""]}', '2021-03-30 09:17:40pm');
INSERT INTO wx.word (id, mess, date) VALUES (60, '{"english":"documentary","chinese":["adj.(文献的，文件的；记录的，纪实的)","n.((文献)纪录片)","","",""]}', '2021-03-30 09:19:14pm');
INSERT INTO wx.word (id, mess, date) VALUES (61, '{"english":"execute","chinese":["vt.(实行，实施，履行)","vt.(<律>执行(法令)，使(法律文件)生效)","","",""]}', '2021-03-30 09:21:16pm');
INSERT INTO wx.word (id, mess, date) VALUES (62, '{"english":"executive","chinese":["adj.(实行的，执行的，行政的)","n.((总)经理，董事，高管，行政负责人)","n.((政府的)行政部门)","",""]}', '2021-03-30 09:24:13pm');
INSERT INTO wx.word (id, mess, date) VALUES (63, '{"english":"exemplify","chinese":["vt.(例示，举例说明)","","","",""]}', '2021-03-30 09:25:04pm');
INSERT INTO wx.word (id, mess, date) VALUES (64, '{"english":"exert","chinese":["vt.(用(力)，尽(力))","vt.(运用，行使，发挥；施加(压力等))","","",""]}', '2021-03-30 09:26:57pm');
INSERT INTO wx.word (id, mess, date) VALUES (65, '{"english":"exhaust","chinese":["v.(使精疲力尽，使疲惫不堪)","v.(用完，用尽)","v.(汲空，抽完)","n.(排气装置)","n.(废气)"]}', '2021-03-30 09:29:51pm');
INSERT INTO wx.word (id, mess, date) VALUES (66, '{"english":"exist","chinese":["vi.(存在，实际上有)","vi.((尤指在困境或贫困中)生活，生存)","","",""]}', '2021-03-30 09:31:47pm');
INSERT INTO wx.word (id, mess, date) VALUES (67, '{"english":"existence","chinese":["n.(存在，生存，(尤指艰难或无聊的)生活(方式))","","","",""]}', '2021-03-30 09:32:50pm');
INSERT INTO wx.word (id, mess, date) VALUES (68, '{"english":"exotic","chinese":["adj.(由外国引进的)","adj.(吸引人的，漂亮的；珍奇的，奇异的)","n.(外来物，外来品种，外来语)","",""]}', '2021-03-30 09:35:02pm');
INSERT INTO wx.word (id, mess, date) VALUES (69, '{"english":"moral","chinese":["adj.(道德(上)的，道义的)","adj.(品行端正的，有道德的)","n.(寓意，教育意义)","n.(品行，道德规范)",""]}', '2021-03-30 09:37:51pm');
INSERT INTO wx.word (id, mess, date) VALUES (70, '{"english":"morality","chinese":["n.(道德(规范)，伦理；美德)","","","",""]}', '2021-03-30 09:38:39pm');
INSERT INTO wx.word (id, mess, date) VALUES (71, '{"english":"moreover","chinese":["adv.(再者，此外，而且)","","","",""]}', '2021-03-30 09:39:16pm');
INSERT INTO wx.word (id, mess, date) VALUES (72, '{"english":"mostly","chinese":["adv.(几乎全部地，主要地，大部分，基本上)","","","",""]}', '2021-03-30 09:40:01pm');
INSERT INTO wx.word (id, mess, date) VALUES (75, '{"english":"prior","chinese":["adj.(先前的，较早的)","adj.(优先的，更重要的)","","",""]}', '2021-03-31 09:39:58pm');
INSERT INTO wx.word (id, mess, date) VALUES (76, '{"english":"priority","chinese":["n.((时间，顺序等的)先，前)","n.(优先，优先权)","n.(优先事项，最重要的事)","",""]}', '2021-03-31 09:41:43pm');
INSERT INTO wx.word (id, mess, date) VALUES (77, '{"english":"privacy","chinese":["n.(隐居；私事，隐私)","","","",""]}', '2021-03-31 09:42:22pm');
INSERT INTO wx.word (id, mess, date) VALUES (78, '{"english":"private","chinese":["n.(私人的，个人的；秘密的；私立的，私营的)","","","",""]}', '2021-03-31 09:43:09pm');
INSERT INTO wx.word (id, mess, date) VALUES (79, '{"english":"privilege","chinese":["n.(特权，优惠)","n.(特殊的待遇，特殊的荣幸)","","",""]}', '2021-03-31 09:44:12pm');
INSERT INTO wx.word (id, mess, date) VALUES (80, '{"english":"prudent","chinese":["adj.(谨慎的，小心的；有先见之明的；会打算的)","","","",""]}', '2021-03-31 09:45:12pm');
INSERT INTO wx.word (id, mess, date) VALUES (81, '{"english":"submit","chinese":["v.(屈服，服从，投降)","v.(听从，听任)","","",""]}', '2021-03-31 09:46:03pm');
INSERT INTO wx.word (id, mess, date) VALUES (82, '{"english":"subordinate","chinese":["adj.(下级的)","adj.(附属的；次要的)","","",""]}', '2021-03-31 09:47:12pm');
INSERT INTO wx.word (id, mess, date) VALUES (83, '{"english":"subscribe","chinese":["v.(捐助，赞助)","v.(订阅，订购)","v.(同意，签名)","",""]}', '2021-03-31 09:51:54pm');
INSERT INTO wx.word (id, mess, date) VALUES (84, '{"english":"subsequent","chinese":["adj.(随后的，后来的)","","","",""]}', '2021-03-31 09:52:21pm');
INSERT INTO wx.word (id, mess, date) VALUES (85, '{"english":"substance","chinese":["n.(物质，材料)","n.(要旨，基本内容)","n.(实质，本质)","n.(财力，资产)",""]}', '2021-03-31 09:53:51pm');
INSERT INTO wx.word (id, mess, date) VALUES (86, '{"english":"substantial","chinese":["adj.(实质的，真实的)","adj.(坚固的，结实的)","adj.(大量的，富裕的；重要的)","",""]}', '2021-03-31 09:55:00pm');
INSERT INTO wx.word (id, mess, date) VALUES (87, '{"english":"substitute","chinese":["n.(代替者，代替物)","v.(代替，替换)","","",""]}', '2021-03-31 09:55:52pm');
INSERT INTO wx.word (id, mess, date) VALUES (88, '{"english":"subtle","chinese":["adj.(微妙的，巧妙的)","adj.(细微的，细致的)","adj.(细心的，敏锐的)","adj.(精妙的，灵巧的)",""]}', '2021-03-31 09:57:14pm');
INSERT INTO wx.word (id, mess, date) VALUES (89, '{"english":"anguish","chinese":["n.((精神或肉体的)极度痛苦，苦恼)","v.(使痛苦，苦恼，悲痛)","v.(感到苦恼或(极度)悲痛)","",""]}', '2021-03-31 09:58:50pm');
INSERT INTO wx.word (id, mess, date) VALUES (90, '{"english":"annoy","chinese":["vt.(使愤怒，使生气)","vt.(打搅，骚扰)","","",""]}', '2021-03-31 10:00:37pm');
INSERT INTO wx.word (id, mess, date) VALUES (91, '{"english":"annual","chinese":["adj.(每年的，年度的，一年一次的)","adj.(全年的)","n.(年报，年刊，年鉴)","n.(一年生植物，一季生植物)",""]}', '2021-03-31 10:02:08pm');
INSERT INTO wx.word (id, mess, date) VALUES (92, '{"english":"anchor","chinese":["n.(锚)","n.(精神支柱，靠山，给人以安全感的人(或物))","v.(抛锚，停留)","v.(固定，扎根)",""]}', '2021-03-31 10:03:32pm');
INSERT INTO wx.word (id, mess, date) VALUES (93, '{"english":"stand","chinese":["v.(站，站立)","v.(坐落，位于)","v.(经受，忍受)","n.(台，座)",""]}', '2021-04-01 11:02:22pm');
INSERT INTO wx.word (id, mess, date) VALUES (94, '{"english":"standard","chinese":["n.((品质)标准，水平，规格，规范)","n.(行为标准，道德水准)","adj.(普通的，正常的，标准的)","adj.(规范的)",""]}', '2021-04-05 10:21:30pm');
INSERT INTO wx.word (id, mess, date) VALUES (95, '{"english":"standpoint","chinese":["n.(立场，观点)","","","",""]}', '2021-04-05 10:22:05pm');
INSERT INTO wx.word (id, mess, date) VALUES (96, '{"english":"stance","chinese":["n.((公开表明的)观点，态度，立场)","n.((尤指体育运动中的)站立姿势)","","",""]}', '2021-04-05 10:23:19pm');
INSERT INTO wx.word (id, mess, date) VALUES (97, '{"english":"","chinese":["","","","",""]}', '2021-05-08 08:33:55am');