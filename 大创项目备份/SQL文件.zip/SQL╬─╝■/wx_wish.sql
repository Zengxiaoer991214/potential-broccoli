create table wish
(
    id     int auto_increment
        primary key,
    u_i_id int  null,
    school text null,
    date   text null,
    talk   text null
);

INSERT INTO wx.wish (id, u_i_id, school, date, talk) VALUES (1, 1, 'xxxx大学', '2021/12/2', '页面相关事件处理函数户下拉动作');
INSERT INTO wx.wish (id, u_i_id, school, date, talk) VALUES (2, 1, 'xxx大学', '2021/10/2', '期函数--监听页面加载,生命周期函数--监听页面初次渲染完成');
INSERT INTO wx.wish (id, u_i_id, school, date, talk) VALUES (3, 1, 'x大学', '2021/9/2', '生命周载,生命周期函数--监听页面初次渲染完成');
INSERT INTO wx.wish (id, u_i_id, school, date, talk) VALUES (4, 1, 'xx大学', '2021/12/2', '生命周期函数--监听页面加载,生命周期函数--监听页面初次渲染完成');