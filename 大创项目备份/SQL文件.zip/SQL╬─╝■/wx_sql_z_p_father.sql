create table p_father
(
    p_f_id   int auto_increment
        primary key,
    p_f_name text null,
    p_f_son  text null
);

INSERT INTO wx_sql_z.p_father (p_f_id, p_f_name, p_f_son) VALUES (4, '经济学', '2<<3<<4<<5<<6<<7<<8<<');
INSERT INTO wx_sql_z.p_father (p_f_id, p_f_name, p_f_son) VALUES (5, '法学', '9<<10<<11<<');
INSERT INTO wx_sql_z.p_father (p_f_id, p_f_name, p_f_son) VALUES (6, '教育学', '12<<13<<14<<15<<');
INSERT INTO wx_sql_z.p_father (p_f_id, p_f_name, p_f_son) VALUES (7, '文学', '16<<17<<18<<');
INSERT INTO wx_sql_z.p_father (p_f_id, p_f_name, p_f_son) VALUES (8, '历史学', '19<<');
INSERT INTO wx_sql_z.p_father (p_f_id, p_f_name, p_f_son) VALUES (9, '工学', '20<<21<<22<<23<<24<<25<<26<<27<<28<<29<<');
INSERT INTO wx_sql_z.p_father (p_f_id, p_f_name, p_f_son) VALUES (10, '农学', '30<<31<<32<<33<<');
INSERT INTO wx_sql_z.p_father (p_f_id, p_f_name, p_f_son) VALUES (11, '医学', '34<<35<<36<<37<<38<<39<<40<<');
INSERT INTO wx_sql_z.p_father (p_f_id, p_f_name, p_f_son) VALUES (12, '军事学', '41<<');
INSERT INTO wx_sql_z.p_father (p_f_id, p_f_name, p_f_son) VALUES (13, '管理学', '42<<43<<44<<45<<46<<47<<');
INSERT INTO wx_sql_z.p_father (p_f_id, p_f_name, p_f_son) VALUES (14, '艺术学', '48<<');