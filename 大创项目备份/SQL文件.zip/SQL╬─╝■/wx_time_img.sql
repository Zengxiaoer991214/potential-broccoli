create table time_img
(
    t_i_id  int(4) auto_increment
        primary key,
    t_i_url text not null
)
    charset = utf8mb4;

INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (1, 'https://s1.ax1x.com/2020/07/15/Ud14sA.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (2, 'https://s1.ax1x.com/2020/07/15/Ud15qI.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (3, 'https://s1.ax1x.com/2020/07/15/Ud17If.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (4, 'https://s1.ax1x.com/2020/07/15/Ud1TdP.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (5, 'https://s1.ax1x.com/2020/07/15/Ud1oZt.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (6, 'https://s1.ax1x.com/2020/07/15/Ud1bi8.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (7, 'https://s1.ax1x.com/2020/07/15/Ud1LRg.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (8, 'https://s1.ax1x.com/2020/07/15/Ud1qJS.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (9, 'https://s1.ax1x.com/2020/07/15/Ud1jMj.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (10, 'https://s1.ax1x.com/2020/07/15/Ud1OzQ.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (11, 'https://s1.ax1x.com/2020/07/15/Ud1xLn.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (12, 'https://s1.ax1x.com/2020/07/15/Ud1vss.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (13, 'https://s1.ax1x.com/2020/07/15/Ud3kz4.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (14, 'https://s1.ax1x.com/2020/07/15/Ud3SZq.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (15, 'https://s1.ax1x.com/2020/07/15/Ud3pd0.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (16, 'https://s1.ax1x.com/2020/07/15/Ud3PiT.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (17, 'https://s1.ax1x.com/2020/07/15/Ud39oV.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (18, 'https://s1.ax1x.com/2020/07/15/Ud3iJU.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (19, 'https://s1.ax1x.com/2020/07/15/Ud3ZLR.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (20, 'https://s1.ax1x.com/2020/07/15/Ud3FWF.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (21, 'https://s1.ax1x.com/2020/07/15/Ud3EQJ.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (22, 'https://s1.ax1x.com/2020/07/15/Ud3Vy9.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (23, 'https://s1.ax1x.com/2020/07/15/Ud3ndx.jpg');
INSERT INTO wx.time_img (t_i_id, t_i_url) VALUES (24, 'https://s1.ax1x.com/2020/07/15/Ud3me1.jpg');