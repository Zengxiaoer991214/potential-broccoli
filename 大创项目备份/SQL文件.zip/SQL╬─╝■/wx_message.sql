create table message
(
    id       int auto_increment
        primary key,
    text     text          null,
    nickname text          null,
    ip       text          null,
    phone    text          null,
    date     text          null,
    count    int default 0 null
);

INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (9, '<a href="https://blog.lin2mei.cn/archives/2021222">https://blog.lin2mei.cn/archives/2021222</a>', '这个用户很神秘', '117.175.10.165', '||null', '2021-03-11 05:23:51', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (11, '<a href ="https://blog.lin2mei.cn/archives/202132">https://blog.lin2mei.cn/archives/202132</a>', '这个用户很神秘', '117.175.10.165', '||null', '2021-03-11 05:31:38', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (20, '不知道该怎样和不想失去的人说再见 于是我说 很高兴认识你', '你今天开心吗', '111.45.128.158', 'iPhone||14.3', '2021-03-14 12:59:21pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (21, '我不开心', '这个用户很神秘', '39.144.53.39', 'iPhone||13.61', '2021-03-19 12:28:37pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (22, '我也不开心', '这个用户很神秘', '223.104.175.209', 'iPhone||14.3', '2021-03-20 07:06:29pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (23, '吃点糖吧', '这个用户很神秘', '39.144.53.76', 'iPhone||13.61', '2021-03-20 11:25:55pm', 1);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (24, '吃了也不长肉，白吃', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-03-21 07:36:21am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (25, '业余时间，忙里偷闲，优化了一下网页的UI，希望可以长期维持下去。', '这个用户很神秘', '111.45.128.158', 'iPhone||13.23', '2021-03-21 11:38:25am', 1);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (29, '我已经快一百啦', '这个用户很神秘', '39.144.53.21', 'iPhone||13.61', '2021-03-21 11:19:24pm', 1);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (30, '加油啦 我也有120了', '这个用户很神秘', '42.248.39.168', 'iPhone||14.3', '2021-03-21 11:20:38pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (31, '太瘦了 晚上多吃点吧', '这个用户很神秘', '39.144.53.21', 'iPhone||13.61', '2021-03-22 02:34:13pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (32, '我也有很努力的吃呀，可今非昔比', '这个用户很神秘', '42.249.28.130', 'iPhone||14.3', '2021-03-22 02:40:03pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (33, '什么今非昔比  给自己整的还挺有文学', '这个用户很神秘', '39.144.53.21', 'iPhone||13.61', '2021-03-22 07:08:10pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (34, '吃了好多呢 网站设计还好看吧', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-03-22 07:48:11pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (35, '好看 我刚吃饭', '这个用户很神秘', '39.144.53.21', 'iPhone||13.61', '2021-03-22 09:02:05pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (36, '我做事情也不比以前专注了，我感觉我考研可能是气氛组了。这几天心情一直很烦躁，自己手上还有项目没做好，也没人理解我。我每天还得看考研，选了个学校，书都买好了，后面发现收分实在是有点高，也不知道那个破学校 凭啥收那么高。', '这个用户很神秘', '42.249.28.130', 'iPhone||14.3', '2021-03-22 11:26:08pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (37, '慢慢来吧   考研还有时间呢 先认真做好一件事 ', '这个用户很神秘', '39.144.53.21', 'iPhone||13.61', '2021-03-22 11:47:25pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (38, '你说的对 我应该认认真真做好每一件事情，对了，你晚上得早点休息', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-03-23 07:00:50am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (39, '一定要有学上呀，加油！', '这个用户很神秘', '182.204.161.231', 'iPhone||14.3', '2021-03-26 12:02:38am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (40, '会的', '这个用户很神秘', '39.144.53.16', 'iPhone||13.61', '2021-03-26 07:56:18pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (41, '今天解封了，我好不开心呀 ', '这个用户很神秘', '113.225.163.135', 'iPhone||14.3', '2021-03-27 06:37:37pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (42, '解封了为什么不开心呢', '这个用户很神秘', '39.144.53.181', 'iPhone||13.61', '2021-03-28 03:21:56am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (43, '烦心事太多了呗', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-03-28 09:59:25pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (44, '你可以跟我倾诉 如果你愿意的话 ', '这个用户很神秘', '39.144.53.181', 'iPhone||13.61', '2021-03-28 10:12:13pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (45, '感觉压力和烦恼不仅仅来自自己生活中，我自己的想法也有问题，明明得好好考研，自己还非得想着esp8266和stm32的事情；明明自己以后肯定会走后端，天天还想着看点前端的东西；英语 英语单词也记不住，别的 别的也搞不好', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-03-29 02:01:22pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (46, '做自己喜欢的事情 但也要为以后考虑  别总想太多  开心才最重要 不是吗 ', '这个用户很神秘', '112.39.149.58', 'iPhone||13.61', '2021-03-29 03:52:34pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (47, '英语咋学呀 俺不会', '这个用户很神秘', '42.249.14.104', 'iPhone||14.3', '2021-03-29 08:22:23pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (48, '我就背单词 我也没有更好的办法', '这个用户很神秘', '39.144.53.169', 'iPhone||13.61', '2021-03-29 09:19:28pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (53, '<p>但单词也记不住要怎么办呢', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-03-30 06:20:57am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (54, '那咱们就考虑考虑找个班上 搬砖怎么样', '这个用户很神秘', '112.39.149.57', 'iPhone||13.61', '2021-03-30 08:35:25am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (55, '<p>行 这就去找个班上<br />
<img src="https://pic.lin2mei.cn/1617064750449.jpg" alt="FDBB59F22BC143EFBD9D5144AA31746C.jpeg" /></p>
', '这个用户很神秘', '42.249.62.66', 'iPhone||14.3', '2021-03-30 08:39:16am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (56, '<p>洗完澡 吃个饭 下午一节课 然后图书馆 可就是心里空空的</p>
', '这个用户很神秘', '39.144.53.53', 'iPhone||13.61', '2021-03-30 10:25:40am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (58, '<p>俺下午也只有一节课，完事就回寝室学习，分到考研自习室了，但是我转让给别人了。</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||13.23', '2021-03-30 11:14:11am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (59, '<p>真好啊一切都顺顺利利的 不像我 回来之后没一件好事</p>
', '这个用户很神秘', '112.39.149.57', 'iPhone||13.61', '2021-03-30 11:47:56am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (60, '<p>你补考过了吗，咋回不顺心呢？肯定会有别的事情顺心的哈 别难过</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-03-30 12:04:35pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (61, '<p>没有 哈哈哈</p>
', '这个用户很神秘', '39.144.53.53', 'iPhone||13.61', '2021-03-30 01:30:32pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (62, '<p>啊？咋会这样呢 你是不是没有认真呀 我准备上成都信息工程大学</p>
', '这个用户很神秘', '42.249.62.66', 'iPhone||14.3', '2021-03-30 01:32:43pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (63, '<p>行啊 有目标了就好好复习吧</p>
', '这个用户很神秘', '39.144.53.92', 'iPhone||13.61', '2021-03-30 03:14:17pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (64, '<p>微信小程序开发 我愿称之为21世纪最差的开发，这个项目之后，我再开发weapp 我就是大傻逼<img src="https://pic.lin2mei.cn/1617112631669.png" alt="image.png" /></p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||13.23', '2021-03-30 09:57:15pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (65, '<p>你 还好吗？</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-04 03:34:57pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (66, '<p>你呢 有没有想我啊哈哈哈哈</p>
', '这个用户很神秘', '112.39.149.82', 'iPhone||13.61', '2021-04-04 06:43:31pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (67, '<p>哈哈哈哈 有 你信吗</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-04 06:54:34pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (68, '<p>骗人的小狗</p>
', '这个用户很神秘', '112.39.149.82', 'iPhone||13.61', '2021-04-04 07:17:47pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (69, '<p>俺一直都是小狗了</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-04 10:33:01pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (70, '<p>哦 原来是一直都在骗我 哈哈哈</p>
', '这个用户很神秘', '112.39.149.82', 'iPhone||13.61', '2021-04-04 10:37:37pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (71, '<p>没有嗷 说着玩的 最近在忙一个比赛 好几天了 天天写代码 脖子疼死了</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-04 10:38:56pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (72, '<p>注意身体 你本来就不太行 别累坏了</p>
', '这个用户很神秘', '112.39.149.82', 'iPhone||13.61', '2021-04-04 10:42:50pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (73, '<p>谁说我不行的！', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-04 10:43:40pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (74, '<p>我靠 好费劲 我得进这网页好多次才能看见 我说的是身体', '这个用户很神秘', '112.39.149.82', 'iPhone||13.61', '2021-04-04 10:48:20pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (75, '<p>俺说的也是身体<br />
网站很卡吗<br />
不会吧</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-05 06:32:28pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (76, '<p>有点吧  而且我也不知道你啥时候说话</p>
', '这个用户很神秘', '112.39.149.82', 'iPhone||13.61', '2021-04-05 07:30:45pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (77, '<p>回去再改进改一下<br />
我做比赛有个老师想把我留在沈阳理工<br />
他说 留下来的话 可以帮我找最好的导师<br />
然后 只要过线 后面的事情 就不要我操心了<br />
我该怎么办</p>
', '这个用户很神秘', '182.204.170.59', 'iPhone||14.3', '2021-04-06 08:53:07am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (78, '<p>你可以先学着看看吧 如果你觉得考别的学校吃力的话 这个老师是个不错的选择 但如果你想回家那边 那你就好好准备考研</p>
', '这个用户很神秘', '39.144.53.11', 'iPhone||13.61', '2021-04-06 10:39:21am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (79, '<p>你呢 你要去哪里呀 <mark>嘻嘻</mark></p>
', '这个用户很神秘', '182.204.170.59', 'iPhone||14.3', '2021-04-06 12:13:57pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (80, '<p>还没想好 数学学不好 心里烦 想流眼泪哈哈哈哈</p>
', '这个用户很神秘', '39.144.53.11', 'iPhone||13.61', '2021-04-06 01:19:27pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (81, '<p>你都没学好 那俺更不行了</p>
', '这个用户很神秘', '182.204.170.59', 'iPhone||14.3', '2021-04-06 01:20:14pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (82, '<p>慢慢来吧 别那么早的否定你自己</p>
', '这个用户很神秘', '39.144.53.11', 'iPhone||13.61', '2021-04-06 03:56:29pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (83, '<p>有些人 就是烦，把你的好心当成驴肝肺(；′⌒`)</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-06 04:40:20pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (84, '<p>嗯嗯 我明白了</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-06 04:40:44pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (85, '<p>生活很难<br />
你我都要加油啦</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-06 10:45:49pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (86, '<p>祝你考研顺利</p>
', '这个用户很神秘', '112.39.149.82', 'iPhone||13.61', '2021-04-06 11:12:19pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (87, '<p>你也是哈<br />
不要垂头丧气的哟</p>
', '这个用户很神秘', '42.249.1.233', 'iPhone||14.3', '2021-04-06 11:21:18pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (88, '<p><img src="https://pic.lin2mei.cn/1618037697449.jpg" alt="409B3D1BF48243D291B9D5064F9682E9.jpeg" /><br />
能帮帮我吗</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-10 02:55:11pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (89, '<p><img src="https://pic.lin2mei.cn/1618315969166.jpg" alt="4AB3FF3EE3FE4C0FB5A07EDF3C42DB58.jpeg" /></p>
', '这个用户很神秘', '112.39.149.88', 'iPhone||13.61', '2021-04-13 08:12:53pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (90, '<p>k π的时候 不需要区分一下左右极限吗</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-13 08:14:44pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (91, '<p>问老师吧 比我靠谱</p>
', '这个用户很神秘', '112.39.149.88', 'iPhone||13.61', '2021-04-13 11:25:34pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (92, '<p>最近还好吧 烦心事过了吗</p>
', '这个用户很神秘', '182.204.172.64', 'iPhone||14.3', '2021-04-13 11:35:08pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (93, '<p>也就那样吧 你呢</p>
', '这个用户很神秘', '39.144.53.113', 'iPhone||13.61', '2021-04-14 09:23:13am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (94, '<p>还好啦 一般般吧</p>
', '这个用户很神秘', '42.249.44.208', 'iPhone||14.3', '2021-04-14 01:43:31pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (95, '<p>嘿嘿 我烫了个发</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-14 10:45:46pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (96, '<p>发张照片看看</p>
', '这个用户很神秘', '112.39.149.88', 'iPhone||13.61', '2021-04-14 11:24:20pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (97, '<p>不给看 哈哈哈哈哈哈 你为啥睡那么晚</p>
', '这个用户很神秘', '42.249.23.207', 'iPhone||14.3', '2021-04-15 09:51:17am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (98, '<p>小气鬼</p>
', '这个用户很神秘', '39.144.53.113', 'iPhone||13.61', '2021-04-15 11:20:01am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (99, '<p>哈哈哈哈哈哈哈哈哈 我可不是小气鬼</p>
', '这个用户很神秘', '42.249.23.207', 'iPhone||14.3', '2021-04-15 11:20:36am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (100, '<p>就是</p>
', '这个用户很神秘', '39.144.53.113', 'iPhone||13.61', '2021-04-15 11:21:29am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (101, '<p>我不是 你才是呢</p>
', '这个用户很神秘', '42.249.23.207', 'iPhone||14.3', '2021-04-15 11:22:52am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (102, '<p>李林是</p>
', '这个用户很神秘', '39.144.53.113', 'iPhone||13.61', '2021-04-15 11:24:50am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (103, '<p>气死我了 不和你玩了</p>
', '这个用户很神秘', '42.249.23.207', 'iPhone||14.3', '2021-04-15 11:34:44am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (104, '<p>小气鬼 哼哼</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-15 05:35:39pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (105, '<p>行行行 我小气 小样</p>
', '这个用户很神秘', '39.144.53.113', 'iPhone||13.61', '2021-04-15 09:10:00pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (106, '<p>没有学习动力了 能不能鼓励鼓励我</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-16 11:48:24am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (107, '<p>不好好学习就要搬砖</p>
', '这个用户很神秘', '112.39.149.88', 'iPhone||13.61', '2021-04-16 03:15:31pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (108, '<p>你的头像是情头吗</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-16 03:54:23pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (109, '<p>呜呜 居然没获奖 哭了</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-16 04:26:36pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (110, '<p>不是 那就下次继续努力</p>
', '这个用户很神秘', '112.39.149.88', 'iPhone||13.61', '2021-04-16 05:25:26pm', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (111, '<p>俺能加你吗</p>
', '这个用户很神秘', '111.45.128.158', 'iPhone||14.3', '2021-04-17 10:00:43am', 0);
INSERT INTO wx.message (id, text, nickname, ip, phone, date, count) VALUES (112, '<p>可以呀</p>
', '这个用户很神秘', '112.39.149.88', 'iPhone||13.61', '2021-04-17 11:29:42am', 0);