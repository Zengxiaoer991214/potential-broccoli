create table time_msg
(
    t_m_id         bigint(13)           not null comment '不同任务的id'
        primary key,
    t_m_u_i_id     int(8)               not null comment '确定哪个任务是哪一个用户',
    t_m_title      text                 null comment '日常任务的名称',
    t_m_time       text                 null comment '任务时间长度',
    t_m_color      text                 null comment '任务卡片的颜色',
    t_m_date       text                 null comment '任务创建时间',
    t_m_s_doCount  int(4)     default 0 null comment '总的应当完成次数',
    t_m_s_didCount int(4)     default 0 null comment '实际上完成的次数',
    t_m_start      text                 null comment '任务起始时间',
    t_m_end        text                 null comment '任务终止时间',
    t_m_doing      tinyint(1) default 1 null comment '是否正在进行',
    t_m_isDone     tinyint(1)           null comment '当天是否完成',
    t_m_time_count int(4)     default 0 null comment '当天应当完成的次数',
    t_m_do_count   int(4)     default 0 null comment '当天实际完成的次数',
    t_m_isend      tinyint(1) default 0 null comment '是否结束',
    constraint time_msg_ibfk_1
        foreign key (t_m_u_i_id) references user_info (u_i_id)
)
    charset = utf8mb4;

create index t_m_u_i_id
    on time_msg (t_m_u_i_id);

INSERT INTO wx.time_msg (t_m_id, t_m_u_i_id, t_m_title, t_m_time, t_m_color, t_m_date, t_m_s_doCount, t_m_s_didCount, t_m_start, t_m_end, t_m_doing, t_m_isDone, t_m_time_count, t_m_do_count, t_m_isend) VALUES (1597915412438, 1, '11', '35', 'background-color:rgba(124,252,0,0.3)', '2020/8/20', 2, 0, '1597852800', '1597939200', 0, 1, 1, 0, 0);