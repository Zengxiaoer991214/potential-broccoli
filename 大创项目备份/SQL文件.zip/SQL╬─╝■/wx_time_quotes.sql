create table time_quotes
(
    t_q_id  int(4) auto_increment
        primary key,
    t_q_str text not null
)
    charset = utf8mb4;

INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (1, '去做你害怕的事，害怕自然就会消失。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (2, '为了明天的希望，让我们忘了今天的痛苦。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (3, '灰心生失望，失望生动摇，动摇生失败。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (4, '伟大的作品不是靠力量，而是靠坚持来完成的。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (5, '人生就是一个与人性弱点搏斗的过程，你要战胜的不仅仅是敌人，更是你自己。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (6, '真理的发见，或道德责任的完成，都引起我们的欢欣，使我们整个生命震颤。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (7, '人生哪有那么多幸运，只是别人在努力，你假装没看见罢了。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (8, '承诺或许并不沉重，只是我们的肩膀过於软弱无力。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (9, '生活是一种选择，你可以从中选到你所想要得到的，以及你所想要失去的任何东西。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (10, '人只有献身于社会，才能找出那短暂而有风险的生命的意义。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (11, '不能自立自强的人，绝对不会有远大的抱负，不处于艰苦的环境，不会有宽广的志向。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (12, '友谊就像彩虹，会在你闯过暴风雨时带来那一片光明。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (13, '如果青春的时光在闲散中度过，那么回忆岁月将是一场凄凉的悲剧。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (14, '时间的三大杀手：拖延、犹豫不决、目标不明确。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (15, '看着别人的故事，流着自己的眼泪。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (16, '我们都有绝望的时候，只有在勇敢面对的时候才知道自己有多坚强。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (17, '收心、用心、会心，抛开一切，全力以赴。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (18, '没有足够的实力就不可能敢为天下先。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (19, '伟大的理想只有经过忘我的斗争和牺牲才能胜利实现。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (20, '没有压力的生活就会空虚，没有压力的青春就会枯萎，没有压力的生命就会黯淡。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (21, '生命，那是自然付给人类去雕琢的宝石。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (22, '冲动是魔鬼，因为它只会害人。遇事要冷静对待。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (23, '天才，就是百分之一的灵感加上百分之九十九的血汗。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (24, '真正的智慧不是预知未来，而是知道现在，享受现在的一切，不必担心现在和将来。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (25, '不要因一场薄雾，便认定前面没有什么景物。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (26, '这个世界并不会在意你的自尊，而是要求你在自我感觉良好之前先有所成就。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (27, '做了自己能做的事的人是个人;做了自己想做的事的人是个神。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (28, '志不真则心不热，心不热则功不贤。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (29, '努力就是一种成功，尽力就是一种知足。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (30, '让过去真的成为过去，让我们拿得起放得下，让时间埋葬无奈的回忆。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (31, '每天肩上新增的不是痛苦，是沉稳的素养。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (32, '既然一切都会过去，那我们一定要抓住现在的。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (33, '人生最大的破产是绝望，最大的资产是希望。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (34, '在年轻时代经历几次挫折，对人是大有裨益的。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (35, '莪葽和曾今說再見，未來是莪自己德!');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (36, '拍马屁的人多了，不是别人的问题，而是你自己。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (37, '首先细心思考，然后果断决定，最后坚忍不拔地去做。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (38, '行动是成功的阶梯，行动越多，登得越高。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (39, '冲动是魔鬼，偶尔当当魔鬼也不算错误，但还是记得一条，不要触犯法律。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (40, '心随境转是凡夫，境随心转是圣贤。');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (41, '我学历不高，但我是读过书的人 ——罗永浩');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (42, ' 一个有洁癖的人，他才会把守护平等公正变成自己的本能。 ——老罗');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (43, '我们每天在科技公司上班，实际上解决的并不是科学问题，而是人的问题。——罗永浩');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (44, '我从来没有那么多的勇敢，我只是有一点点勇敢，但是在普遍懦弱的中国，这已经是难能可贵的品质了。——罗永浩');
INSERT INTO wx.time_quotes (t_q_id, t_q_str) VALUES (45, '我出身不好,教养也差,但一直努力尝试做一个体面的人');