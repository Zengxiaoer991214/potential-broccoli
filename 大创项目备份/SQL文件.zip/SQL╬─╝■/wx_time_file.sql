create table time_file
(
    id      int auto_increment
        primary key,
    article text null,
    text    text null,
    date    text null,
    title   text null
);

INSERT INTO wx.time_file (id, article, text, date, title) VALUES (71, '<p><span style="font-family: inherit; font-size: inherit; -webkit-tap-highlight-color: transparent;">        2020年考研的报名人数为341万人，比起2019年的时候，增加了超50万人，增长幅度更是超过了17%，而近年来考研的人数也是屡创新高。</span></p><p><br></p><p>　　</p><p><img src="http://pic.lin2mei.cn/tmp_380b586ca198a2cd8aa2e5513a83e797.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p><br></p><p>　　今年高考的报考人数，比去年增加了40万人，考研人数的增加人数竟然已经超过了高考。可见考研的热度越来越大，几乎很多的大学生在面临毕业的时候，都会选择考研。</p><p><br></p><p>　　而今年考研的热度更是空前，在2021年考研预报名的当天，中国研究生招生信息网竟然“崩溃”了，今年考研的报名人数更是超出了预期，相比也会刷新历史。</p><p><br></p><p>　　<img src="http://pic.lin2mei.cn/tmp_64f4d3b1c447a0ad384e31ea62846e5f.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p><br></p><p><br></p><p>　　2021年考研预报名研招网“崩溃”，报名人数超预期，考研越来越难？</p><p><br></p><p>　　2021年考研预报名的当天，很多的考生都早早的守着时间准备好，打算时间一到就开始报名，但是却因为报名的人数过多，网站的访问量过大，网站“崩溃”了，很多考生没有放弃，在电脑前反复的尝试，但是网站还是处于“崩溃”的状态。</p><p><br></p><p>　　很多考生都比较担心自己会不会报上名，虽然只要在报名截止的日期内报名缴费成功就可以了，但是早报名的学生，可以选择考场，一些大城市的考场一般比较“热门”，如果不提前报名的话，到最后就只好去比较远的地区考场考试了，还是比较麻烦的。</p><p><img src="http://pic.lin2mei.cn/tmp_526b1ccf81beddc7b5363c57a5fdd75c.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p><br></p><p>　　</p><p><br></p><p>　　其实，每年在考研报考的时候，都会因为报名的人数太多，很多考生出现网页刷新不出来的情况，但是在这种情况基本不会持续太长时间，只要考生耐心等待，基本上一会就好了，但是今年这样的情况持续了一个上午，晚上的时候，才逐渐好转。</p><p><br></p><p>　　报名缴费出现问题</p><p><br></p><p>　　可能因为今年的考研报名人数实在是超出了预期，有很多的考生在报名缴费阶段的时候还出现了问题，有的考生一开始缴费的时候，没有显示出缴费成功的界面，为了报名成功，考生只好再次缴费，结果第二次缴费成功了。</p><p><br></p><p>　　<img src="http://pic.lin2mei.cn/tmp_aba3d910d55c5b9253ebc6cc2958b72e.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p><br></p><p><br></p><p>　　现在报名成功了，但是很多的考生出现了两次缴费的情况，很多考生开始担心，多缴的那次报名费可不可以退还呢？一般来说，多缴的费用是会退还的，考生也不用太担心了。</p><p><br></p><p>　　考研一年比一年难，为何热度还是不减？</p><p><br></p><p>　　每年考研的报名人数都很多，而且近年来还在不停的增加，几乎每年的研究生网站都会出现因为报名人数过多而导致“崩溃”的现象，但是今年确实比较严重。考研可以说一年比一年要难了，为什么考研的热度还是不减呢？</p><p><br></p><p>　　<img src="http://pic.lin2mei.cn/tmp_7d05c6beee1b77ab6265bb42d6b8f884.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p><br></p><p><br></p><p>　　1、本科文凭的“含金量”下降</p><p><br></p><p>　　在很多年以前，本科生的人数还没有那么多，基本上本科的文凭就像是“敲门砖”，有这个文凭不仅就业不成问题，并且还都是很多比较好的企业抢着录取。但是随着大学生越来越多，本科文凭的“含金量”下降，大学生好像也不是很“值钱”了。</p><p><br></p><p>　　学生为了提高自己的文凭的含金量，开始通过考研的方式，成为研究生，这样可以有更好的文凭，在毕业之后也可以有更好的发展。</p><p><br></p><p>　　<img src="http://pic.lin2mei.cn/tmp_39bd7e618e35659e77d6ac56b682f7f1.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p><br></p><p><br></p><p>　　2、就业竞争力上升</p><p><br></p><p>　　随着社会的不断发展，现在社会上不再缺少能力强、技术比较多的员工。市场主要缺少还是全方位高端的人才。现在很多的本科生在面临毕业的时候会发现，自己投的简历仿佛就是“石沉大海”，要不就是薪资待遇太低了，很多学生都不能接受。</p><p><br></p><p>　　最后在毕业前还是决定考研了，通过考研提升自己的能力，等到研究生毕业之后，说不定可以提高自己的社会竞争力，在就业的时候也可以避免“屡屡碰壁”了。</p><p><br></p><p>　　<img src="http://pic.lin2mei.cn/tmp_b481630eebc15ba4ea401a26dad825b9.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p><br></p><p><br></p><p>　　3、薪资待遇等问题</p><p><br></p><p>　　现在很多企业不管是本科生还是研究生都会有，但是可能本科生的薪资就会比研究生差很多，还有一些之后岗位的晋升等，都是会优先考虑研究生专业的员工，本科生晋升和涨工资的机会就要比一些研究生要少。</p><p><br></p><p>　　更让人“难受”的是，可能你在公司工作了很多，之后新来的研究生毕业的大学生比你的职位更高了，来的时候可能是你带他，之后她和你平级，后来可能就成为你的领导了，也很让人无奈但也是事实。</p><p><img src="http://pic.lin2mei.cn/tmp_d6a35361382b145e754baeae38bd1463.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p><br></p><p>　　</p><p><br></p><p>　　寄语：</p><p><br></p><p>　　学历的提升真的很有必要，如果可以考上一个比较的研究生大学的话，也可以为将来的就业争取到更多的机会。但是考研的过程不仅辛苦，等到学生考上研究生之后，也是并不轻松的。</p><p><br></p><p>　　如果学生没有做好准备的话，那么还是仔细想想自己适不适合考研，不然即便是考上了之后可能也很难毕业，或者成为考研的“陪跑”，就得不偿失了。<img src="http://pic.lin2mei.cn/tmp_3e26007adcfe2af50b3d147dc2804649.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p><br></p>', '2021年考研预报名研招网“崩溃”，报名人数超预期，考研越来越难？ 
        2020年考研的报名人数为341万人，比起2019年的时候，增加了超50万人，增长幅度更是超过了17%，而近年来考研的人数也是屡创新高。

　　


　　今年高考的报考人数，比去年增加了40万人，考研人数的增加人数竟然已经超过了高考。可见考研的热度越来越大，几乎很多的大学生在面临毕业的时候，都会选择考研。

　　而今年考研的热度更是空前，在2021年考研预报名的当天，中国研究生招生信息网竟然“崩溃”了，今年考研的报名人数更是超出了预期，相比也会刷新历史。

　　


　　2021年考研预报名研招网“崩溃”，报名人数超预期，考研越来越难？

　　2021年考研预报名的当天，很多的考生都早早的守着时间准备好，打算时间一到就开始报名，但是却因为报名的人数过多，网站的访问量过大，网站“崩溃”了，很多考生没有放弃，在电脑前反复的尝试，但是网站还是处于“崩溃”的状态。

　　很多考生都比较担心自己会不会报上名，虽然只要在报名截止的日期内报名缴费成功就可以了，但是早报名的学生，可以选择考场，一些大城市的考场一般比较“热门”，如果不提前报名的话，到最后就只好去比较远的地区考场考试了，还是比较麻烦的。


　　

　　其实，每年在考研报考的时候，都会因为报名的人数太多，很多考生出现网页刷新不出来的情况，但是在这种情况基本不会持续太长时间，只要考生耐心等待，基本上一会就好了，但是今年这样的情况持续了一个上午，晚上的时候，才逐渐好转。

　　报名缴费出现问题

　　可能因为今年的考研报名人数实在是超出了预期，有很多的考生在报名缴费阶段的时候还出现了问题，有的考生一开始缴费的时候，没有显示出缴费成功的界面，为了报名成功，考生只好再次缴费，结果第二次缴费成功了。

　　


　　现在报名成功了，但是很多的考生出现了两次缴费的情况，很多考生开始担心，多缴的那次报名费可不可以退还呢？一般来说，多缴的费用是会退还的，考生也不用太担心了。

　　考研一年比一年难，为何热度还是不减？

　　每年考研的报名人数都很多，而且近年来还在不停的增加，几乎每年的研究生网站都会出现因为报名人数过多而导致“崩溃”的现象，但是今年确实比较严重。考研可以说一年比一年要难了，为什么考研的热度还是不减呢？

　　


　　1、本科文凭的“含金量”下降

　　在很多年以前，本科生的人数还没有那么多，基本上本科的文凭就像是“敲门砖”，有这个文凭不仅就业不成问题，并且还都是很多比较好的企业抢着录取。但是随着大学生越来越多，本科文凭的“含金量”下降，大学生好像也不是很“值钱”了。

　　学生为了提高自己的文凭的含金量，开始通过考研的方式，成为研究生，这样可以有更好的文凭，在毕业之后也可以有更好的发展。

　　


　　2、就业竞争力上升

　　随着社会的不断发展，现在社会上不再缺少能力强、技术比较多的员工。市场主要缺少还是全方位高端的人才。现在很多的本科生在面临毕业的时候会发现，自己投的简历仿佛就是“石沉大海”，要不就是薪资待遇太低了，很多学生都不能接受。

　　最后在毕业前还是决定考研了，通过考研提升自己的能力，等到研究生毕业之后，说不定可以提高自己的社会竞争力，在就业的时候也可以避免“屡屡碰壁”了。

　　


　　3、薪资待遇等问题

　　现在很多企业不管是本科生还是研究生都会有，但是可能本科生的薪资就会比研究生差很多，还有一些之后岗位的晋升等，都是会优先考虑研究生专业的员工，本科生晋升和涨工资的机会就要比一些研究生要少。

　　更让人“难受”的是，可能你在公司工作了很多，之后新来的研究生毕业的大学生比你的职位更高了，来的时候可能是你带他，之后她和你平级，后来可能就成为你的领导了，也很让人无奈但也是事实。


　　

　　寄语：

　　学历的提升真的很有必要，如果可以考上一个比较的研究生大学的话，也可以为将来的就业争取到更多的机会。但是考研的过程不仅辛苦，等到学生考上研究生之后，也是并不轻松的。

　　如果学生没有做好准备的话，那么还是仔细想想自己适不适合考研，不然即便是考上了之后可能也很难毕业，或者成为考研的“陪跑”，就得不偿失了。

', '2020/09/31 10:28', '2021年考研预报名研招网“崩溃”，报名人数超预期，考研越来越难？ ');
INSERT INTO wx.time_file (id, article, text, date, title) VALUES (72, '<img src="http://pic.lin2mei.cn/tmp_3d9778886e6273f73301f17fcd518026.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p><br></p><p>2020考研在初试成绩出来的时候网上有：宁夏大学文学院专业课个位数现象，网友质疑，最后官方也没有给大家一个满意的交代。最后录取全部是调剂考生。这种现象我认为2021年考生就要尽力避开，是大坑。专业课压分，你总分低最后连调剂的资格都没有，只能再战或找其他出路。</p><p><br></p><p>最近在网上考生与院校官方交流的情况我留意的是：咨询该校保不保护第一愿考生是大家最为关心的，我们看看各个高校的官方回复：</p><p><br></p><p>广西大学，官方回复：欢迎报考广西大学，保护第一志愿。</p><p><br></p><p>点评：广西大学是211大学，是每年的调剂大户。文学院，新闻传播，风景园林往年在网上有压分现象出现。</p><p><br></p><p>杭州电子科技大学：不歧视本科，一视同仁：优先第一志愿，有缺额才会调剂。</p><p><br></p><p>建议多调查，最后再下决定，电院有负面消息传出。</p><p><br></p><p>上海理工大学：我校近几年一直优先录取一志愿考生。</p><p><br></p><p>点评：控制与计算机专业有负面压分传闻，复试调剂时不到时间不拒绝，不解锁，招办电话无人接。</p><p><br></p><p>浙江工商大学：同学，你好，我们会优先考虑第一志愿填报的学生。</p><p><br></p><p>点评：经济学有压分传闻。</p><p><br></p><p>浙江师范大学，先录取一志愿</p><p><br></p><p>有歧视第一志愿考生的传闻。</p><p><img src="http://pic.lin2mei.cn/tmp_9e2cbd9984b25641955c27d6303fe1d4.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p><br></p><p>南昌大学：我校一贯保护一志愿，欢迎一志愿报考我校。该校初试，复试没有发现负面新闻。</p><p><br></p><p>上海海事大学：一志愿招不满的情况下才会调剂。该校没有发现初试，复试的负面新闻。</p><p><br></p><p>上海电力大学：你好，我校优先录取一志愿上线考生。</p><p><br></p><p>未发现有负面传闻。</p><p><br></p><p>上海工程技术大学：一般一志愿优先。</p><p><br></p><p>点评：网友会说那二般呢？该校有不保护第一志愿传闻。</p><p><br></p><p>上海对外经贸大学：这么多年来一志愿考生都是优先录取的。</p><p><br></p><p>点评：该校的国际商贸专业有压分负面消息传出。</p><p><br></p><p>北京科技大学：优先录取一志愿。</p><p><br></p><p>点评：该校翻译，语言学有压分传言。</p><p><br></p><p>中国地质大学：复试录取一志愿优先。</p><p><br></p><p>该校武汉校区艺术设计有压分传闻。</p><p><br></p><p>湘潭大学：符合录取条件的情况下，优先保护一志愿。</p><p><br></p><p>该校没发现有初试，复试的负面传闻。</p><p><br></p><p>西安电子科技大学：我校各专业均一志愿优先。</p><p><br></p><p>通信工程专业有压分传闻。</p><p><br></p><p>大连海事大学：优先录取一志愿。</p><p><br></p><p>该校未发现有负面传闻。</p><p><br></p><p>青海大学：进入复试阶段的一志愿考生，我们原则上优先录取。</p><p><br></p><p>该校也没有发现有负面传闻。</p><p><br></p><p>北方工业大学：我校第一志愿上线复试合格考生优先录取。</p><p><br></p><p>该校没有发现有负面传闻。</p><p><br></p><p>第二军医大学：先一志愿再调剂。</p><p><br></p><p>该校也没有发现考研方面的负面消息。</p><p><br></p><p>长江大学：一志愿考生优先录取。该校也正常，未发现有负面消息。</p><p><br></p><p>天津师范大学：各学院对参加复试合格的考生一般优先录取第一志愿考生，再录取调剂考生。</p><p><br></p><p>该校的师范类专业，教育学综合333，新闻传播，心里学有压分消息传出。</p><p><br></p><p>昆明理工大学：同学你好，一志愿优先录取。该校正常，未发现有负面新闻，值得报考。</p><p><br></p><p>华北电力大学：（北京，保定）优先录取第一志愿考生。该校正常，没有发现有负面传闻。</p><p><br></p><p>中国社会科学院大学：所有院系都是优先录取本专业一志愿考生。正常。</p><p><br></p><p>石河子大学：同学，你好，我校优先录取一志愿。正常。</p><p><br></p><p>中央财经大学：近七年从未接受调剂，只接受一志愿。该校总体多年来是保护第一志愿高校。但是心里学专硕网上有压分消息传出。</p><p><br></p><p>小编写出上面的消息供广大考研生参考，各个高校网传消息是否真实，也不可能去核实，有则改之，无则加冕。还有需多高校没有写，只能靠你们自己去了解了。</p><p><br></p><p>这里我再次提醒广大考研生：选择大于努力。</p>', '


2020考研在初试成绩出来的时候网上有：宁夏大学文学院专业课个位数现象，网友质疑，最后官方也没有给大家一个满意的交代。最后录取全部是调剂考生。这种现象我认为2021年考生就要尽力避开，是大坑。专业课压分，你总分低最后连调剂的资格都没有，只能再战或找其他出路。

最近在网上考生与院校官方交流的情况我留意的是：咨询该校保不保护第一愿考生是大家最为关心的，我们看看各个高校的官方回复：

广西大学，官方回复：欢迎报考广西大学，保护第一志愿。

点评：广西大学是211大学，是每年的调剂大户。文学院，新闻传播，风景园林往年在网上有压分现象出现。

杭州电子科技大学：不歧视本科，一视同仁：优先第一志愿，有缺额才会调剂。

建议多调查，最后再下决定，电院有负面消息传出。

上海理工大学：我校近几年一直优先录取一志愿考生。

点评：控制与计算机专业有负面压分传闻，复试调剂时不到时间不拒绝，不解锁，招办电话无人接。

浙江工商大学：同学，你好，我们会优先考虑第一志愿填报的学生。

点评：经济学有压分传闻。

浙江师范大学，先录取一志愿

有歧视第一志愿考生的传闻。


南昌大学：我校一贯保护一志愿，欢迎一志愿报考我校。该校初试，复试没有发现负面新闻。

上海海事大学：一志愿招不满的情况下才会调剂。该校没有发现初试，复试的负面新闻。

上海电力大学：你好，我校优先录取一志愿上线考生。

未发现有负面传闻。

上海工程技术大学：一般一志愿优先。

点评：网友会说那二般呢？该校有不保护第一志愿传闻。

上海对外经贸大学：这么多年来一志愿考生都是优先录取的。

点评：该校的国际商贸专业有压分负面消息传出。

北京科技大学：优先录取一志愿。

点评：该校翻译，语言学有压分传言。

中国地质大学：复试录取一志愿优先。

该校武汉校区艺术设计有压分传闻。

湘潭大学：符合录取条件的情况下，优先保护一志愿。

该校没发现有初试，复试的负面传闻。

西安电子科技大学：我校各专业均一志愿优先。

通信工程专业有压分传闻。

大连海事大学：优先录取一志愿。

该校未发现有负面传闻。

青海大学：进入复试阶段的一志愿考生，我们原则上优先录取。

该校也没有发现有负面传闻。

北方工业大学：我校第一志愿上线复试合格考生优先录取。

该校没有发现有负面传闻。

第二军医大学：先一志愿再调剂。

该校也没有发现考研方面的负面消息。

长江大学：一志愿考生优先录取。该校也正常，未发现有负面消息。

天津师范大学：各学院对参加复试合格的考生一般优先录取第一志愿考生，再录取调剂考生。

该校的师范类专业，教育学综合333，新闻传播，心里学有压分消息传出。

昆明理工大学：同学你好，一志愿优先录取。该校正常，未发现有负面新闻，值得报考。

华北电力大学：（北京，保定）优先录取第一志愿考生。该校正常，没有发现有负面传闻。

中国社会科学院大学：所有院系都是优先录取本专业一志愿考生。正常。

石河子大学：同学，你好，我校优先录取一志愿。正常。

中央财经大学：近七年从未接受调剂，只接受一志愿。该校总体多年来是保护第一志愿高校。但是心里学专硕网上有压分消息传出。

小编写出上面的消息供广大考研生参考，各个高校网传消息是否真实，也不可能去核实，有则改之，无则加冕。还有需多高校没有写，只能靠你们自己去了解了。

这里我再次提醒广大考研生：选择大于努力。
', '2020/09/31 10:28', '如何看待考研生与高校的信息交流');
INSERT INTO wx.time_file (id, article, text, date, title) VALUES (73, '<p>新华社北京日电 记者28日从教育部获悉，国务院学位委员会、教育部近日印发关于进一步严格规范学位与研究生教育质量管理的若干意见，提出实行研究生培养全过程评价制度，关键节点突出学术规范和学术道德要求。将学位论文作假行为作为信用记录，纳入全国信用信息共享平台。

文件强调，对学术不端行为，坚持“零容忍”，一经发现坚决依法依规、从快从严进行彻查。对有学术不端行为的当事人以及相关责任人，根据情节轻重，依法依规给予党纪政纪校纪处分和学术惩戒；违反法律法规的，应及时移送有关部门查处。对学术不端查处不力的单位予以问责。将学位论文作假行为作为信用记录，纳入全国信用信息共享平台。

文件同时指出，要坚持质量检查关口前移，切实发挥资格考试、学位论文开题和中期考核等关键节点的考核筛查作用，完善考核组织流程，丰富考核方式，落实监督责任，提高考核的科学性和有效性。进一步加强和严格课程考试。完善和落实研究生分流退出机制，对不适合继续攻读学位的研究生要及早按照培养方案进行分流退出，做好学生分流退出服务工作，严格规范各类研究生学籍年限管理。</p>', '
新华社北京日电 记者28日从教育部获悉，国务院学位委员会、教育部近日印发关于进一步严格规范学位与研究生教育质量管理的若干意见，提出实行研究生培养全过程评价制度，关键节点突出学术规范和学术道德要求。将学位论文作假行为作为信用记录，纳入全国信用信息共享平台。

文件强调，对学术不端行为，坚持“零容忍”，一经发现坚决依法依规、从快从严进行彻查。对有学术不端行为的当事人以及相关责任人，根据情节轻重，依法依规给予党纪政纪校纪处分和学术惩戒；违反法律法规的，应及时移送有关部门查处。对学术不端查处不力的单位予以问责。将学位论文作假行为作为信用记录，纳入全国信用信息共享平台。

文件同时指出，要坚持质量检查关口前移，切实发挥资格考试、学位论文开题和中期考核等关键节点的考核筛查作用，完善考核组织流程，丰富考核方式，落实监督责任，提高考核的科学性和有效性。进一步加强和严格课程考试。完善和落实研究生分流退出机制，对不适合继续攻读学位的研究生要及早按照培养方案进行分流退出，做好学生分流退出服务工作，严格规范各类研究生学籍年限管理。
', '2020/09/31 10:28', '学位论文作假行为将纳入全国信用信息共享平台');
INSERT INTO wx.time_file (id, article, text, date, title) VALUES (74, '<p>         日前，国务院学位委员会、教育部印发《专业学位研究生教育发展方案（2020-2025）》。方案指出，到2025年，以国家重大战略、关键领域和社会重大需求为重点，增设一批硕士、博士专业学位类别，将硕士专业学位研究生招生规模扩大到硕士研究生招生总规模的三分之二左右，大幅增加博士专业学位研究生招生数量。<img src="http://pic.lin2mei.cn/tmp_5cef7e7f51aedee466abe62c7cfd039c.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p><br></p>', '
         日前，国务院学位委员会、教育部印发《专业学位研究生教育发展方案（2020-2025）》。方案指出，到2025年，以国家重大战略、关键领域和社会重大需求为重点，增设一批硕士、博士专业学位类别，将硕士专业学位研究生招生规模扩大到硕士研究生招生总规模的三分之二左右，大幅增加博士专业学位研究生招生数量。

', '2020/09/31 10:28', '教育部：专硕将扩大到研究生招生三分之二');
INSERT INTO wx.time_file (id, article, text, date, title) VALUES (75, '<p><img src="http://pic.lin2mei.cn/tmp_aa1bfaaae5cce013d84a131b93b5aeba.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p>每一年的考研就是一场生死交战，因为很多学生为了考研备战已久，对于考研要知彼知己，对于考研的作文有一定的了解会更胜一筹，预祝各位考生百战百胜，以下是给大家整理的供参考2019考研英语作文必备范文及译文：被互联网异化的交流，希望可以帮到大家</p><p><br></p><p>Write an essay of 160-200 words based on the following drawing. In your essay, you should:</p><p><br></p><p>（1) describe the drawing briefly,</p><p><br></p><p>（2) explain its intended meaning, and then</p><p><br></p><p>（3) state your point of view.</p><p><br></p><p>范文：</p><p><br></p><p>As is illustrated in the picture, a couple sleeps on the same bed but they seem to be rather isolated from each other. Their oral communication has been replaced by online chatting. This picture reveals the in-depth problem of modern people’s alienation from each other, even among family members.</p><p><br></p><p>The issue is attributed to two factors. In the first place, modern people are fully occupied by their work and business, which causes so much tension that there is little time left for communication with each other. Everybody is busy all the time because of the pressure of survival in the society, which deprives them of a casual way of life. In the second place, the prevailing use of the Internet makes it easier for people to contact each other. However, the convenience of sending instant messages to anybody around the world prevents people from the pleasure of the face-to-face communication. In a sense, the addiction to internet exchange makes humans mechanical.</p><p><br></p><p>People should be aware that the modern modes of communication cannot take the place of traditional ones. If the couple in the drawing continues to behave like this, their close relationship might be ruined, perhaps even becoming the “closest stranger” some day. Direct communications, in contrast, helps construct more human connections among people.</p><p><br></p><p>译文：</p><p><br></p><p>正如图中所示，一对夫妇睡在同一张床上，但是他们看起来却彼此孤立。上网聊天代替了他们的口头交流。这幅图深刻地揭示了一个问题，就是现代人彼此之间趋于异化，即使是在家庭成员之间。</p><p><br></p><p>这种情况主要取决于两个原因。首先，现代人都忙于自己的工作，过大的压力导致他们没有时间与其他人进行交流。由于社会生存压力，每个人都非常忙碌，从而失去了休闲的生活方式。第二，互联网的广泛使用使人们联系彼此都变得更加方便。但是，虽然可以随时给世界上任何一个人发即时消息，但是这种便利使人们失去了面对面交流的乐趣。从某种意义上说，过于沉溺于互联网的交流使人们变得更加机械。</p><p><br></p><p>我认为人们应该意识到现代的交流方式不能取代传统的交流方式。如果图中的这幅夫妻继续这样下去的话，他们会毁掉曾经的亲密关系，甚至会变成最亲近的陌生人。相反，直接的交流能够帮助人们建立更加人性化的联系。</p><p><br></p><p>闪光词汇及词组：</p><p><br></p><p>in-depth: adj. 深入的</p><p><br></p><p>alienation: n. 异化，分离</p><p><br></p><p>tension: n. 紧张状态，不安</p><p><br></p><p>deprives sb. of: 使某人失去</p><p><br></p><p>casual: adj. 随意的，不经意的</p><p><br></p><p>prevailing: adj. 流行的。广泛的</p><p><br></p><p>万能句型：</p><p><br></p><p>As is illustrated in the picture…</p><p><br></p><p>This picture reveals the in-depth problem of…</p><p><br></p><p>The issue is attributed to two factors.</p><p><br></p><p>In a sense…</p>', '

每一年的考研就是一场生死交战，因为很多学生为了考研备战已久，对于考研要知彼知己，对于考研的作文有一定的了解会更胜一筹，预祝各位考生百战百胜，以下是给大家整理的供参考2019考研英语作文必备范文及译文：被互联网异化的交流，希望可以帮到大家

Write an essay of 160-200 words based on the following drawing. In your essay, you should:

（1) describe the drawing briefly,

（2) explain its intended meaning, and then

（3) state your point of view.

范文：

As is illustrated in the picture, a couple sleeps on the same bed but they seem to be rather isolated from each other. Their oral communication has been replaced by online chatting. This picture reveals the in-depth problem of modern people’s alienation from each other, even among family members.

The issue is attributed to two factors. In the first place, modern people are fully occupied by their work and business, which causes so much tension that there is little time left for communication with each other. Everybody is busy all the time because of the pressure of survival in the society, which deprives them of a casual way of life. In the second place, the prevailing use of the Internet makes it easier for people to contact each other. However, the convenience of sending instant messages to anybody around the world prevents people from the pleasure of the face-to-face communication. In a sense, the addiction to internet exchange makes humans mechanical.

People should be aware that the modern modes of communication cannot take the place of traditional ones. If the couple in the drawing continues to behave like this, their close relationship might be ruined, perhaps even becoming the “closest stranger” some day. Direct communications, in contrast, helps construct more human connections among people.

译文：

正如图中所示，一对夫妇睡在同一张床上，但是他们看起来却彼此孤立。上网聊天代替了他们的口头交流。这幅图深刻地揭示了一个问题，就是现代人彼此之间趋于异化，即使是在家庭成员之间。

这种情况主要取决于两个原因。首先，现代人都忙于自己的工作，过大的压力导致他们没有时间与其他人进行交流。由于社会生存压力，每个人都非常忙碌，从而失去了休闲的生活方式。第二，互联网的广泛使用使人们联系彼此都变得更加方便。但是，虽然可以随时给世界上任何一个人发即时消息，但是这种便利使人们失去了面对面交流的乐趣。从某种意义上说，过于沉溺于互联网的交流使人们变得更加机械。

我认为人们应该意识到现代的交流方式不能取代传统的交流方式。如果图中的这幅夫妻继续这样下去的话，他们会毁掉曾经的亲密关系，甚至会变成最亲近的陌生人。相反，直接的交流能够帮助人们建立更加人性化的联系。

闪光词汇及词组：

in-depth: adj. 深入的

alienation: n. 异化，分离

tension: n. 紧张状态，不安

deprives sb. of: 使某人失去

casual: adj. 随意的，不经意的

prevailing: adj. 流行的。广泛的

万能句型：

As is illustrated in the picture…

This picture reveals the in-depth problem of…

The issue is attributed to two factors.

In a sense…
', '2020/09/31 10:28', '考研英语作文必背范文及译文：被互联网异化的交流');
INSERT INTO wx.time_file (id, article, text, date, title) VALUES (76, '<p><img src="http://pic.lin2mei.cn/tmp_b4345cdd5ab442eb2be3dd64851e92ed.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p>(1)考生应在规定时间浏览报考须知，并按照网上公告要求报名；

(2)实名注册后，牢记注册用户名及密码；

(3)填写考生信息，认真阅读报名页面的提示信息，准确填报；

(4)千万不要开启有网页拦截功能的软件；

(5)报考专业名称前面有“专业学位”字样的为专业学位的专业，其他为学术型专业；

(6)报名过程中，要认真阅读各省市招办、招生单位和报考点发布的网报公告；

(7)牢记网报系统生成的报名号；

(8)在北京、天津、河北、山西、内蒙古、辽宁、吉林、黑龙江、上海、江苏、浙江、河南、湖北、湖南、广东、广西、海南、重庆、安徽、福建、江西、山东、四川、贵州、云南、西藏、陕西、甘肃、青海、宁夏、新疆等报考点报考的考生，需要网上支付报考费；

(9)修改或查询自己的报名信息；

(10) 预报名期间的报名信息是有效数据，同学们不需要重复填报；

(11) 网上确认时间在2020年11月10日之前。</p>', '

(1)考生应在规定时间浏览报考须知，并按照网上公告要求报名；

(2)实名注册后，牢记注册用户名及密码；

(3)填写考生信息，认真阅读报名页面的提示信息，准确填报；

(4)千万不要开启有网页拦截功能的软件；

(5)报考专业名称前面有“专业学位”字样的为专业学位的专业，其他为学术型专业；

(6)报名过程中，要认真阅读各省市招办、招生单位和报考点发布的网报公告；

(7)牢记网报系统生成的报名号；

(8)在北京、天津、河北、山西、内蒙古、辽宁、吉林、黑龙江、上海、江苏、浙江、河南、湖北、湖南、广东、广西、海南、重庆、安徽、福建、江西、山东、四川、贵州、云南、西藏、陕西、甘肃、青海、宁夏、新疆等报考点报考的考生，需要网上支付报考费；

(9)修改或查询自己的报名信息；

(10) 预报名期间的报名信息是有效数据，同学们不需要重复填报；

(11) 网上确认时间在2020年11月10日之前。
', '2020/09/31 10:28', '看懂这张图，搞定考研网报流程！');
INSERT INTO wx.time_file (id, article, text, date, title) VALUES (91, '<p><img src="http://pic.lin2mei.cn/tmp_4c6025a727461fc7ddd6b8e0982ef4629c6db4d35d655e3b.jpg" width="100%" data-custom="id=abcd&amp;role=god"></p><p>全新柏林吉他，没用过</p><p><br></p><p>联系方式:177 7777 7777</p>', '
全新柏林吉他，没用过

联系方式:177 7777 7777
', null, null);