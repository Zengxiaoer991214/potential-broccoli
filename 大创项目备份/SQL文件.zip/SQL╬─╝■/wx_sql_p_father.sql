create table p_father
(
    p_f_id   int auto_increment
        primary key,
    p_f_name text null,
    p_f_son  text null
);

INSERT INTO wx_sql.p_father (p_f_id, p_f_name, p_f_son) VALUES (4, '哲学', '2<<');
INSERT INTO wx_sql.p_father (p_f_id, p_f_name, p_f_son) VALUES (5, '经济学', '3<<4<<5<<');
INSERT INTO wx_sql.p_father (p_f_id, p_f_name, p_f_son) VALUES (6, '法学', '6<<7<<8<<9<<10<<11<<');
INSERT INTO wx_sql.p_father (p_f_id, p_f_name, p_f_son) VALUES (7, '教育学', '12<<13<<14<<');
INSERT INTO wx_sql.p_father (p_f_id, p_f_name, p_f_son) VALUES (8, '文学', '15<<16<<17<<');
INSERT INTO wx_sql.p_father (p_f_id, p_f_name, p_f_son) VALUES (9, '历史学', '18<<19<<20<<');
INSERT INTO wx_sql.p_father (p_f_id, p_f_name, p_f_son) VALUES (10, '理学', '21<<22<<23<<24<<25<<26<<27<<28<<29<<30<<31<<32<<33<<34<<35<<36<<37<<38<<39<<40<<41<<42<<43<<44<<45<<46<<47<<');
INSERT INTO wx_sql.p_father (p_f_id, p_f_name, p_f_son) VALUES (11, '工学', '48<<49<<50<<51<<52<<53<<54<<55<<56<<57<<58<<59<<60<<61<<62<<63<<64<<65<<66<<67<<68<<69<<70<<71<<72<<73<<74<<75<<76<<77<<78<<79<<80<<81<<82<<83<<84<<85<<86<<87<<88<<89<<');
INSERT INTO wx_sql.p_father (p_f_id, p_f_name, p_f_son) VALUES (12, '农学', '90<<91<<92<<93<<94<<95<<96<<97<<98<<99<<100<<101<<102<<');
INSERT INTO wx_sql.p_father (p_f_id, p_f_name, p_f_son) VALUES (13, '医学', '103<<104<<105<<106<<107<<108<<109<<110<<111<<112<<113<<114<<115<<');
INSERT INTO wx_sql.p_father (p_f_id, p_f_name, p_f_son) VALUES (14, '军事学', '116<<117<<118<<119<<120<<121<<122<<123<<124<<125<<');
INSERT INTO wx_sql.p_father (p_f_id, p_f_name, p_f_son) VALUES (15, '管理学', '126<<127<<128<<129<<130<<');
INSERT INTO wx_sql.p_father (p_f_id, p_f_name, p_f_son) VALUES (16, '艺术学', '131<<132<<133<<134<<135<<');