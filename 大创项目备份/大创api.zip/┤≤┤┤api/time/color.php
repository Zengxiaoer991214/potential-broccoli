<?php
function json_to_array(){	
		if(is_array($_POST)&&count($_POST)>0){
			return $_POST;
		}
		else{
			$json = file_get_contents('php://input');
			$arr =  json_decode($json,true);
			return $arr;
		}
	}
$arr = json_to_array();


$count = $arr['x'];
$color = [];

$conn = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin","wx");
//获取最大id
$sql = "select t_c_id from time_color where t_c_id=(select max(t_c_id) from time_color)";
$fh = mysqli_query($conn,$sql);
$MAX = mysqli_fetch_array($fh)['t_c_id'];
//随机产生指定个颜色

for($x=0;$x<$count;$x++){
	$things = rand(1,$MAX);
	$sql1 = "select * from time_color where t_c_id = $things";
	$result = mysqli_query($conn,$sql1);
	$row = mysqli_fetch_array($result);
	array_push($color,$row['t_c_color']);
}
$color = array("color"=>$color);
$message= array("code"=>0,"data"=>$color,"msg"=>"");
echo (json_encode($message));
?>