<?php
header('Content-Type:application/json');  
$conn = mysqli_connect("localhost","root","12345678","wx");

// $things1 = rand(1,30);
// $things2 = 1;

// $sql1 = "select * from time_img where t_i_id = $things1";
// $result1 = mysqli_query($conn,$sql1);
// $row1 = mysqli_fetch_array($result1);

// $sql2 = "select * from time_quotes where t_q_id = $things2";
// $result2= mysqli_query($conn,$sql2);
// $row2 = mysqli_fetch_array($result2);

// //echo $row['t_i_url'];
// $message = array('url'=>$row1['t_i_url'], 'quotes'=>$row2['t_q_str']);
// //echo $row1['t_i_url'];
// //echo $row2['t_q_str'];
// echo (json_encode($message));

$str="https://s1.ax1x.com/2020/07/15/Ud14sA.jpg
https://s1.ax1x.com/2020/07/15/Ud15qI.jpg
https://s1.ax1x.com/2020/07/15/Ud17If.jpg
https://s1.ax1x.com/2020/07/15/Ud1TdP.jpg
https://s1.ax1x.com/2020/07/15/Ud1oZt.jpg
https://s1.ax1x.com/2020/07/15/Ud1bi8.jpg
https://s1.ax1x.com/2020/07/15/Ud1LRg.jpg
https://s1.ax1x.com/2020/07/15/Ud1qJS.jpg
https://s1.ax1x.com/2020/07/15/Ud1jMj.jpg
https://s1.ax1x.com/2020/07/15/Ud1OzQ.jpg
https://s1.ax1x.com/2020/07/15/Ud1xLn.jpg
https://s1.ax1x.com/2020/07/15/Ud1vss.jpg
https://s1.ax1x.com/2020/07/15/Ud3kz4.jpg
https://s1.ax1x.com/2020/07/15/Ud3SZq.jpg
https://s1.ax1x.com/2020/07/15/Ud3pd0.jpg
https://s1.ax1x.com/2020/07/15/Ud3PiT.jpg
https://s1.ax1x.com/2020/07/15/Ud39oV.jpg
https://s1.ax1x.com/2020/07/15/Ud3iJU.jpg
https://s1.ax1x.com/2020/07/15/Ud3ZLR.jpg
https://s1.ax1x.com/2020/07/15/Ud3FWF.jpg
https://s1.ax1x.com/2020/07/15/Ud3EQJ.jpg
https://s1.ax1x.com/2020/07/15/Ud3Vy9.jpg
https://s1.ax1x.com/2020/07/15/Ud3ndx.jpg
https://s1.ax1x.com/2020/07/15/Ud3me1.jpg";

$arr = explode("\n",$str);
$arrlength = count($arr);
for($x=0;$x<$arrlength;$x++) {
	//$sql = "INSERT INTO time_quotes(t_q_str) VALUES ($arr[$x])";
	$sql = sprintf("INSERT INTO time_img(t_i_url) VALUES ('%s');", $arr[$x] ); 
	mysqli_query($conn,$sql);
	/*echo mysqli_error($conn);
	die();*/
}

?>