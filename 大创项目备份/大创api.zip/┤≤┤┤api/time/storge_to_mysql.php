<?php
function json_to_array()
{	
		if(is_array($_POST)&&count($_POST)>0){
			return $_POST;
		}
		else{
			$json = file_get_contents('php://input');
			$arr =  json_decode($json,true);
			return $arr;
		}
	}

$con = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin","wx");
$arr = json_to_array();
$arr_msg = [];
foreach($arr as $value){ 
//	foreach(array_keys($value) as $T){
//		$msg = $value[$T];
//		if(!$msg and $T!='id'){
//			$message = array("code"=>2,"data"=>null,"msg"=>"{$T}  hava a question");
//			array_push($arr_msg, array($value['t_id']=>$message));
//		}
//	}
	
	$k = $value['t_id'];
	$sql = "select * from time_msg where t_m_id = $k";
	$result = mysqli_query($con,$sql);
	if($result){
		$t_m_do_count = $value['do_count'];
//		$str1="UPDATE time_msg SET t_m_s_didCount = t_m_s_didCount + t_m_do_count WHERE t_m_id = $k";
		$str1="UPDATE time_msg SET t_m_s_didCount = t_m_s_didCount + $t_m_do_count,t_m_do_count = $t_m_do_count WHERE t_m_id = $k";
		$result = mysqli_query($con,$str1);
		echo mysqli_error($con);
		$message = array("code"=>0,"data"=>null,"msg"=>"UPDATA OVER");
		array_push($arr_msg, array($value['t_id']=>$message));
	}
	else{
		$str2 = sprintf("INSERT  INTO  time_msg (t_m_u_i_id,t_m_id,t_m_title,t_m_time,t_m_color,t_m_do_count,t_m_time_count) VALUES('%s','%s','%s','%s','%s','%s','%s');",$value['u_id'],$value['t_id'],$value['title'],$value['time'],$value['color'],$value['do_count'],$value['time_count']);
		mysqli_query($con,$str2);
		$message = array("code"=>0,"data"=>null,"msg"=>"INSERT OVER");
		array_push($arr_msg, array($value['t_id']=>$message));
	}
}
echo json_encode($arr_msg);
?>