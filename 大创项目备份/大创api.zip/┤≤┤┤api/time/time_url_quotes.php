<?php
	header('Content-Type:application/json');  
	$conn = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin","wx");
	$M_sql1 = "select t_i_id from time_img where t_i_id=(select max(t_i_id) from time_img)";
	$M_sql2 = "select t_q_id from time_quotes where t_q_id=(select max(t_q_id) from time_quotes)";
	$fh1 = mysqli_query($conn,$M_sql1);
	$fh2 = mysqli_query($conn,$M_sql2);
	$MAX1 = mysqli_fetch_array($fh1)['t_i_id'];
	$MAX2 = mysqli_fetch_array($fh2)['t_q_id'];
	//随机产生个id
	$things1 = rand(1,$MAX1);
	$things2 = rand(1,$MAX2);
	//随机产生图片url
	$sql1 = "select * from time_img where t_i_id = $things1";
	$result1 = mysqli_query($conn,$sql1);
	$row1 = mysqli_fetch_array($result1);
	//随机产生语句
	$sql2 = "select * from time_quotes where t_q_id = $things2";
	$result2= mysqli_query($conn,$sql2);
	$row2 = mysqli_fetch_array($result2);
	//数据柔和
	$sql3 = "select t_c_hex from time_color where 1";
	$result3= mysqli_query($conn,$sql3);
	$row3 = mysqli_fetch_all($result3);
	//print_r($row3);
	$thing = rand(0,count($row3)-1);
	$thing3 = rand(0,count($row3)-1);
	$thing4 = rand(0,count($row3)-1);
	$thing5 = rand(0,count($row3)-1);
	
	//
	$message = array('url'=>$row1['t_i_url'], 'quotes'=>$row2['t_q_str'],'color'=>$row3[$thing][0],'text_color'=>$row3[$thing3][0],'circle_color'=>array('0%'=>$row3[$thing4][0],'100%'=>$row3[$thing5][0]));
	//输出
	echo (json_encode($message))
?>