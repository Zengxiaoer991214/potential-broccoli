<?php
	header('Content-Type:application/json');  

	function receive_json_to_array()
	{
		$json = file_get_contents('php://input');
		//加true转换为数组，不加转换为对象
		$arr =  json_decode($json, true);
		return $arr;
	}
	
	$arr = receive_json_to_array();
	$count = $arr['x'];
	$count2 = $_POST['x'];
	echo $count2;
	echo json_encode("????".$count);


	$conn = mysqli_connect("localhost","root","12345678","wx");
	//获取最大id
	$sql = "select t_c_id from time_color where t_c_id=(select max(t_c_id) from time_color)";
	$fh = mysqli_query($conn,$sql);
	$MAX = mysqli_fetch_array($fh)['t_c_id'];
    //随机产生指定个颜色


for($x=0;$x<$count;$x++){
	$things = rand(1,$MAX);
	$sql1 = "select * from time_color where t_c_id = $things";
	$result = mysqli_query($conn,$sql1);
	$row = mysqli_fetch_array($result);
	$message[$x] = array('color'=>$row['t_c_color']);
}
echo (json_encode($message));
?>