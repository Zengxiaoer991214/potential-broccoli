<?php
	function json_to_array(){	
			if(is_array($_POST)&&count($_POST)>0){
				return $_POST;
			}
			else{
				$json = file_get_contents('php://input');
				$arr =  json_decode($json,true);
				return $arr;
			}
		}
	$arr = json_to_array();
//	print_r($arr);
	$u_id = $arr['u_id'];
//	echo $u_id;
	$t_m_id = $arr['t_id'];
//	echo $t_m_id;
	$title = $arr['title'];
	$color = $arr['color'];
	$time = $arr['time'];
	$date = $arr['t_m_date'];
	$time_count = $arr['time_count'];
	$arr_Date = str_replace(" ", "", $arr['time_date']);
	$arr_Date = explode("-", $arr_Date);
	$time_start = strtotime(date($arr_Date[0]));
	$time_end = strtotime(date($arr_Date[1]));
//	echo $time_start.$time_end;
	$dates = ($time_end-$time_start)/(60*60*24)+1;
	echo $dates;
//	echo $dates."??".$time_count;
//	echo $dates*$time_count;
//	echo time();
	$isdoing = 0;
	if($time_start<time()&&time()<$time_end){
		$isdoing = 1;
	}
	$conn = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin","wx");
	$sql = "INSERT INTO `time_msg`(	t_m_id,
									`t_m_u_i_id`,
									`t_m_title`, 
									`t_m_time`, 
									`t_m_color`, 
									`t_m_date`, 
									`t_m_s_doCount`, 
									`t_m_s_didCount`, 
									`t_m_start`, 
									`t_m_end`, 
									`t_m_doing`, 
									`t_m_isDone`, 
									`t_m_time_count`, 
									`t_m_do_count`)
									VALUES 
									(
									'$t_m_id', 
									'$u_id',
									'$title',
									'$time',
									'$color',
									'$date',
									'$dates',
									0,
									
									'$time_start',
									'$time_end',
									0,
									$isdoing,
									$time_count,
									0)
									";
	$r = mysqli_query($conn,$sql);
//	echo "ah".mysqli_error($conn);
	if($r){
		echo json_encode(array("code"=>0,"data"=>null,"msg"=>"插入成功"));
	}
	else{
		echo json_encode(array("code"=>1,"data"=>null,"msg"=>"服务器发送未知错误，请联系后台管理员"));
	}
?>