<?php
/*
* date:2020/10/20
* author:lilin
* msg:图片上传
*/
//echo "123";
print_r(json_encode($_FILES));
$file = "./uploads/".$_FILES['file']['name'];
if(move_uploaded_file($_FILES['file']['tmp_name'],$file)){
	 
//	echo "Uploaded successfully";
}else{
//	echo "Upload";
}
?>

