<?php
  	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:POST,GET');//表示只允许POST请求
	header('Access-Control-Allow-Headers:x-requested-with, content-type');
	function json_to_array(){	
		if(is_array($_POST)&&count($_POST)>0){
			return $_POST;
		}else{
			$json = file_get_contents('php://input');
			$arr =  json_decode($json,true);
			return $arr;
		}
	}
	$arr = json_to_array();
	$conn = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin","wx");
	function insertNew($arr,$conn){
		echo $arr['list'];
		$date = date("Y/m/d h:i:sa");
		$sql = "insert into memo (time, list) values ('".$date."', '".$arr['list']."')";
		$sqls = "insert into memo (time, list) values ('".$date."', '".$arr['list']."') where id = 0";
		$result = mysqli_query($conn, $sql);
		$results = mysqli_query($conn, $sqls);
		if($result&&$results){
			echo json_encode(array("code"=>200, "data"=>null,"msg"=>""));
			return;
		}
		echo json_encode(array("code"=>301, "data"=>null,"msg"=>""));
	}
	function queryAll($arr,$conn){
		$date = date("Y/m/d h:i:sa");
		$sql = "select * from memo where id = 0";
		$sqls = "select * from memo where id != 0 order by id desc";
		
		$result = mysqli_query($conn, $sql);
		$results = mysqli_query($conn, $sqls);
		if($result&&$results){
			$row = mysqli_fetch_all($result, MYSQLI_ASSOC)[0];
			$row["list"] = json_decode($row["list"]);
			$rows = mysqli_fetch_all($results, MYSQLI_ASSOC);
			echo json_encode(array("code"=>200, "data"=>array("default"=>$row, "list"=>$rows),"msg"=>""));
			return;
		}
		echo json_encode(array("code"=>301, "data"=>null,"msg"=>""));
	}
	switch($arr["type"]){
		case "insertNew":
			insertNew($arr,$conn);
			break;
		case "queryAll":
			queryAll($arr,$conn);
			break;
	}
	