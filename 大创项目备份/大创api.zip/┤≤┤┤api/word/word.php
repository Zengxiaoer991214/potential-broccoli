<?php
	function json_to_array(){	
		if(is_array($_POST)&&count($_POST)>0){
			return $_POST;
		}
		else{
			$json = file_get_contents('php://input');
			$arr =  json_decode($json,true);
			return $arr;
		}
	}
	$arr = json_to_array();
	$conn = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin","wx");
	
	function insert($conn,$arr){
		$date = date('Y-m-d h:i:sa', time());
		$mess = $arr["data"];
		$sql = "insert into word (mess,date) values ('$mess', '$date')";
		$result = mysqli_query($conn, $sql);
		echo json_encode(array("code"=>200,"data"=>$mess,"msg"=>""));
	}
	function query($conn,$arr){
		
		$sql = "select * from word order by id DESC LIMIT 0, 3";
		$result = mysqli_query($conn, $sql);
		$row = mysqli_fetch_all($result, MYSQLI_ASSOC);
		echo json_encode(array("code"=>200,"data"=>$row,"msg"=>""));
	}

	switch ($arr["type"]){
		case "insert":
			insert($conn,$arr);
			break;
		case "query":
			query($conn,$arr);
			break;
	}

?>