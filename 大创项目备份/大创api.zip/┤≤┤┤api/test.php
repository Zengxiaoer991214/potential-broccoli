<?php 
	header('Access-Control-Allow-Origin:*');

	header('Access-Control-Allow-Methods:POST,GET');//表示只允许POST请求

	header('Access-Control-Allow-Headers:x-requested-with, content-type');
require 'php-sdk-7.2.10/autoload.php';

use Qiniu\Auth;

use Qiniu\Storage\UploadManager;

$accessKey = 'BCJXmIiBhoHDLhY3bsRQvA4OQePb-eceoRF3FpkG';

$secretKey = 'ywOQVmkvxHwTAQgBB0WUh8edzTeCQ6LysgL7yi-N';

$auth = new Auth($accessKey, $secretKey);



$bucket = 'wx2332';



// 生成上传Token

$token = $auth->uploadToken($bucket);

$data = array("code"=>200, "data"=>array("token"=>$token),"msg"=>" ");
echo json_encode($data);

?>