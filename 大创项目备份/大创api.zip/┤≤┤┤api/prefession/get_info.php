<?php
	function json_to_array()
	{	
			if(is_array($_POST)&&count($_POST)>0){
				return $_POST;
			}
			else{
				$json = file_get_contents('php://input');
				$arr =  json_decode($json,true);
				return $arr;
			}
		}
	$arr = json_to_array();
	$table = "wx_sql";
	if ($arr['code']==2){
		$table = "wx_sql_z";
	}
	$type = $arr['type'];
	$id = $arr['id'];
	//链接数据表
	$con = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin",$table);
	$sql1 = "select * from p_father";
	$result1 = mysqli_query($con,$sql1);
	$rows = array();
	while($row1=mysqli_fetch_array($result1)){
		$rows[] = $row1;
	}
	$menu_one = $rows;
	//二级菜单
	if($type==2){
		$key = $id;
		foreach($menu_one as $R1){
		if($R1['p_f_id']==$key){
			$messag = $R1['p_f_son'];
			break;
			}
		}
		$messag = explode('<<',$messag); 
		$menu_two = array();
			foreach($messag as $k){
				$sql2 = "select * from p_son where p_s_id = $k";
				$result2 = mysqli_query($con,$sql2);
				if(!$result2){continue;}
				$row2 = mysqli_fetch_array($result2);
				$menu_two[] = array("text"=>$row2['p_s_name'],"id"=>$row2['p_s_id']);
			}
		$find = $menu_two;
	}
	//三级菜单
	if($type==3){
		$key2=$id;
		$sql_4 = "select * from p_body where id = $key2";
		$result_4 = mysqli_query($con,$sql_4);
		$messag2 = mysqli_fetch_array($result_4);
		$text = $messag2['p_b_name'];
		$messag2 = explode('<<',$messag2['p_a_sch']);
		$number = 0;
		foreach($messag2 as $k){
		$sql4 = "select * from p_address where p_a_id = $k";
		$result4 = mysqli_query($con,$sql4);
		if(!$result4){continue;}
		$row4 = mysqli_fetch_array($result4);	
		$number += $row4['p_a_count'];
		}
		$menu_three[] = array("text"=>$text,"id"=>$id,"school_count"=>$number);
		$find = $menu_three;
	}
	//四级菜单
	if($type==4){
		$key1 = $id;
		$sql_3 = "select * from p_son where p_s_id = $key1";
		$result_3 = mysqli_query($con,$sql_3);
		$messag1 = mysqli_fetch_array($result_3)['p_s_son'];
		$messag1 = explode('<<',$messag1);
		foreach($messag1 as $k){
			$sql3 = "select * from p_body where id = $k";
			$result3 = mysqli_query($con,$sql3);
			if(!$result3){continue;}
			$row3 = mysqli_fetch_array($result3);	
			$menu_four [] = array("text"=>$row3['p_b_name'],"id"=>$row3['id'],"code"=>$row3['p_b_code'],"info"=>$row3['info']);
			}
		$find = $menu_four;
	}
	$over_message = array("code"=>0,"data"=>$find,"msg"=>'');
	print_r($over_message);
?>