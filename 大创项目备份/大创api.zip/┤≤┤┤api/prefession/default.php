<?php
function json_to_array()
{	
		if(is_array($_POST)&&count($_POST)>0){
			return $_POST;
		}
		else{
			$json = file_get_contents('php://input');
			$arr =  json_decode($json,true);
			return $arr;
		}
	}

$arr = json_to_array();
$table = "wx_sql";
$code = $arr['code'];
if ($code==2){
	$table = "wx_sql_z";
}
//链接数据表
$con = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin",$table);
$sql1 = "select * from p_father";
$result1 = mysqli_query($con,$sql1);
$rows = array();
while($row1=mysqli_fetch_array($result1)){
	$rows[] = $row1;
}
$menu_one = $rows;
//二级菜单
$messag_2_1 = "2<<";
$messag_2_1 = explode('<<',$messag_2_1); 
foreach($messag_2_1 as $R1){
	if(!$R1){continue;}
	$k = $R1;
	$sql_2 = "select * from p_son where p_s_id = $k";
	$result_2 = mysqli_query($con,$sql_2);
	$row_2 = mysqli_fetch_array($result_2);
	$menu_two[] = array("text"=>$row_2['p_s_name'],"id"=>$row_2['p_s_id']);
	}
//三级菜单
$messag_3_1 = "38<<39<<40<<41<<42<<43<<44<<45<<46<<";
$messag_3_1 = explode('<<',$messag_3_1);
foreach($messag_3_1 as $R1){
	if(!$R1){continue;}
	$k = $R1;
	$number = 0 ;
	//echo  "\n";
	$sql_3_1 = "select * from p_body where id = $k";
	$result_3_1 = mysqli_query($con,$sql_3_1);
	$row_3_1 = mysqli_fetch_array($result_3_1 );	
	$messag_3_2 =$row_3_1['p_a_sch'];
	$messag_3_2 = explode('<<',$messag_3_2);
	foreach($messag_3_2 as $R2){
		if(!$R1){continue;}
		$k = $R2;
		$sql_3_2 = "select * from p_address where p_a_id = $k";
		$result_3_2 = mysqli_query($con,$sql_3_2);
		if($result_3_2){
		$row_3_2 = mysqli_fetch_array($result_3_2)['p_a_count'];	
		}
		$number += $row_3_2;
		}
	if($number!=0){
	$menu_three[] = array("text"=>$row_3_1['p_b_name'],"id"=>$row_3_1['id'],"school_count"=>$number);
	}
}
//print_r(array_values($menu_three));
//四级菜单
$messag_4 = "38<<39<<40<<41<<42<<43<<44<<45<<46<<";
$messag_4 = explode('<<',$messag_4);
foreach($messag_4 as $R1){
	if(!$R1){continue;}
	$k = $R1;
	//echo  "\n";
	$sql_4 = "select * from p_body where id = $k";
	$result_4 = mysqli_query($con,$sql_4);
	$row_4 = mysqli_fetch_array($result_4);	
	$menu_four[] = array("text"=>$row_4['p_b_name'],"id"=>$row_4['id'],"code"=>$row_4['p_b_code'],"info"=>$row_4['info']);
	}
$over_message = array("menu_one"=>$menu_one,"menu_two"=>$menu_two,"menu_three"=>$menu_three,"menu_four"=>$menu_four);
//echo json_encode($over_message);
print_r(array("code"=>$code,"data"=>$over_message,"msg"=>''));
?>
