<?php
	function json_to_array(){	
			if(is_array($_POST)&&count($_POST)>0){
				return $_POST;
			}
			else{
				$json = file_get_contents('php://input');
				$arr =  json_decode($json,true);
				return $arr;
			}
		}

/* 无实际作用，仅仅返回普通的一级菜单*/
	function menu_one($conn){
		$sql = "select p_f_id as id,p_f_name as text from p_father";
		$result = mysqli_query($conn,$sql);
		$menu_one=[];
		while($row = mysqli_fetch_assoc($result)){
			array_push($menu_one,$row);
		}
		return $menu_one;
	}
/*仅返回二级菜单，无法单独使用，需配合下面函数*/
	function menu_two($id,$conn){
		$sql = "select p_f_son from p_father where p_f_id = $id";
		$res = mysqli_query($conn, $sql);
		$row = mysqli_fetch_assoc($res);
		$sons = explode('<<',$row['p_f_son']);
		$son = [];
		$num = count($sons)-1;
		for($i=0;$i<$num;$i++){
			$id = $sons[$i];
			$sql2 = "select * from p_son where p_s_id='$id'";
			$res2 = mysqli_query($conn, $sql2);
			array_push($son, array("id"=>$id,"text"=>mysqli_fetch_assoc($res2)['p_s_name']));
		}
		return $son;
	}
/*返回三级菜单，点击二级菜单时，返回三级简单的菜单*/
	function menu_three($id,$conn){
		$sql = "select p_s_son from p_son where p_s_id = $id";
		$res = mysqli_query($conn, $sql);
		$row = mysqli_fetch_assoc($res);
		$sons = explode('<<',$row['p_s_son']);
		$son = [];
		$num = count($sons)-1;
		for($i=0;$i<$num;$i++){
			$id = $sons[$i];
			$sql3 = "select p_b_code,sc_count,p_b_name from p_body where id='$id'";
			$res3 = mysqli_query($conn, $sql3);
			$row3 = mysqli_fetch_assoc($res3);
			array_push($son, array("id"=>$id, "text"=>$row3['p_b_name'], "code"=>$row3['p_b_code'], "sc_count"=>$row3['sc_count']));
		}
		return $son;
	}
/*点击三级菜单，返回有关于跳转页面的信息*/
	function menu_four($id,$conn){
		$sql = "select p_a_sch from p_body where id = $id";
		$res = mysqli_query($conn, $sql);
		$row = mysqli_fetch_assoc($res);
		$sons = explode('<<',$row['p_a_sch']);
		$son = [];
		$num = count($sons)-1;
		for($i=0;$i<$num;$i++){
			$id = $sons[$i];
			$sql2 = "select p_a_school,p_a_address,p_a_count from p_address where p_a_id='$id'";
			$res2 = mysqli_query($conn, $sql2);
			$row3 = mysqli_fetch_assoc($res2);
			array_push($son, array("id"=>$id,"text"=>array("school"=>$row3['p_a_school'],"address"=>$row3['p_a_address'],"p_a_count"=>$row3['p_a_count'])));	
		}
		return $son;
	}
	function get_otherdata($id,$conn){
		$sql = "select p_b_name as name,p_b_code as code,sc_count as count,p_b_talks as talks from p_body where id = '$id'";
		$res = mysqli_query($conn, $sql);
		$res = mysqli_fetch_assoc($res);
		return $res;
	}
	$arr = json_to_array();
	$table = "wx_sql";
	$code = $arr['code'];
	if ($code==2){
		$table = "wx_sql_z";
	}
//	function pre_type($arr, $conn){
//		$id = $arr['id'];
////		$id2 = $arr['idd'];
//		$menu_two = menu_two($id,$conn);
//		$menu_three = menu_three($menu_two[0]['id'],$conn);
//		echo json_encode(array("code"=>1,"data"=>array("menu_two"=>$menu_two,"menu_three"=>$menu_three),"msg"=>""));
//	}

/*格式化，输出标准的返回格式*/
	function mess_format($arr, $conn){
		
		switch($arr['type']){
			case 1:$data = menu_two($arr['id'],$conn);
				   	echo json_encode(array("code"=>0,"data"=>$data,"mess"=>""));
					break;
			case 2:$data = menu_three($arr['id'],$conn);
					echo json_encode(array("code"=>0,"data"=>$data,"mess"=>""));
					break;
			case 3:$data = menu_four($arr['id'],$conn);
					$data2 = get_otherdata($arr['id'],$conn);
					echo json_encode(array("code"=>0,"data"=>$data,"data2"=>$data2,"mess"=>""));
					break;
		}
		
	}

/*调用上面的二三级菜单，返回，指定二级菜单，和三级菜单的第一个*/
	function menu_two_and_three($arr, $conn){
		$son = menu_two($arr['id'],$conn);
		$son_son = menu_three($son[0]['id'],$conn);
		echo json_encode(array("code"=>0,"data"=>array("menu_two"=>$son,"menu_three"=>$son_son),"msg"=>""));
	}



	$conn = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin",$table);
	if($arr['type']==4){
//		pre_type($arr, $conn);
		menu_two_and_three($arr, $conn);
	}
	else if(in_array($arr['type'],array(1,2,3))){
		mess_format($arr, $conn);
	}
	else{	
	}
?>
