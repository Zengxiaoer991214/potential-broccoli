<?php
//header('Content-Type:application/json');  
function json_array()
	{
		$json = file_get_contents('php://input');
		//加true转换为数组，不加转换为对象
		$arr =  json_decode($json, true);
		return $arr;
	}
	echo json_array()['code'];
?>