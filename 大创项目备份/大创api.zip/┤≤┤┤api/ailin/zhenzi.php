<?php
    header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:POST,GET');//表示只允许POST请求
	header('Access-Control-Allow-Headers:x-requested-with, content-type');
    function json_to_array(){	
    		if(is_array($_POST)&&count($_POST)>0){
    			return $_POST;
    		}
    		else{
    			$json = file_get_contents('php://input');
    			$arr =  json_decode($json,true);
    			return $arr;
    		}
    	}
	$arr = json_to_array();
	$conn = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin","wx");
    require_once('../ZhenziSmsClient.php');
	$client = new  ZhenziSmsClient("https://sms_developer.zhenzikj.com", "105675", "NzFmZmI0YjgtMjBlZC00MmE0LTlkOTktMmViMzM4NTI5YWIw");
    
    $params = array();
	$params['number'] = '17309044584';
	$params['templateId'] = '4131';
	$params['templateParams'] = ['提醒', 'https://ailin'];
	$result=$client->send($params);
    echo($result);


?>