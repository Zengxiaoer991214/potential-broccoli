<?php

    header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:POST,GET');//表示只允许POST请求
	header('Access-Control-Allow-Headers:x-requested-with, content-type');
	require_once('../ZhenziSmsClient.php');
	function getIP(){

        static $IP;

        if (isset($_SERVER)){

            if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])){

                $IP= $_SERVER["HTTP_X_FORWARDED_FOR"];

            } else if (isset($_SERVER["HTTP_CLIENT_IP"])) {

                $IP= $_SERVER["HTTP_CLIENT_IP"];

            } else {

                $IP= $_SERVER["REMOTE_ADDR"];

            }

        } 

    

        else {

    

            if (getenv("HTTP_X_FORWARDED_FOR")){

                $IP= getenv("HTTP_X_FORWARDED_FOR");

            } else if (getenv("HTTP_CLIENT_IP")) {

                $IP= getenv("HTTP_CLIENT_IP");

            } else {

                $IP= getenv("REMOTE_ADDR");

            }

        }

        return $IP;

        }

	function json_to_array(){	

		if(is_array($_POST)&&count($_POST)>0){

			return $_POST;

		}

		else{

			$json = file_get_contents('php://input');

			$arr =  json_decode($json,true);

			return $arr;

		}

	}

	$arr = json_to_array();

	$conn = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin","wx");

	if(!$conn){

		echo"mysql_error";

		echo mysqli_error($conn);

	}

    

    if($arr["type"]=="insert"){

        $text = $arr["text"];

        $date = date('Y-m-d h:i:sa', time());

        $phone = $arr["phone"];

        $ip =  getIP();

        $nickname = $arr["nickname"];

        if($nickname==""){

            $nickname = "这个用户很神秘";

        }

        $sql = "insert into message (text, nickname, ip, phone, date) values  ('$text', '$nickname', '$ip', '$phone', '$date')";

        $result = mysqli_query($conn, $sql);

        if($result){

            

            $client = new  ZhenziSmsClient("https://sms_developer.zhenzikj.com", "105675", "NzFmZmI0YjgtMjBlZC00MmE0LTlkOTktMmViMzM4NTI5YWIw");

            

            $params = array();

            $params['number'] = '17309044584';

            $params['templateId'] = '4131';

            $params['templateParams'] = ['提醒', 'ailin'];

            $result=$client->send($params);

            echo json_encode(array("code"=>200,"data"=>null,"msg"=>"insert success"));

        }

    }elseif ($arr["type"]=="query") {

        $result = mysqli_query($conn, "select * from message ORDER by id DESC");

        if($result){

            $array = mysqli_fetch_all($result, MYSQLI_ASSOC);

            echo json_encode(array("code"=>200,"data"=>$array,"msg"=>"query success"));

        }

    }elseif ($arr["type"]=="check") {

        $ip =  getIP();

        $phone = $arr['phone'];

        $date = date('Y-m-d h:i:sa', time());

        $result = mysqli_query($conn, "select id,date from checks where ip='$ip' and phone ='$phone'");

        print_r($result);

        $row =mysqli_fetch_array($result);

        print_r($row);

        if(mysqli_num_rows($result)==0){

            $result = mysqli_query($conn, "insert into checks (ip, phone, date) values('$ip', '$phone', '$date')");

        }

        else{

            $id = $row["id"];

            $date = $row["date"].",".date('Y-m-d h:i:sa', time());

            $result = mysqli_query($conn, "update checks set count=count+1,date='$date'  where id = '$id'");

        }

    }elseif ($arr["type"]=="monitor") {

        $result = mysqli_query($conn, "select * from checks ORDER BY id DESC");

        $row = mysqli_fetch_all($result, MYSQLI_ASSOC);

        echo json_encode(array("code"=>200, "data"=>$row, "msg"=>"query success"));

    }elseif($arr["type"]=="color"){

        $sql = "select * from time_color";

        $result = mysqli_query($conn, $sql);

        $row = mysqli_fetch_all($result, MYSQLI_ASSOC);

        echo json_encode(array("code"=>200, "data"=>$row, "msg"=>"query success"));

    }elseif($arr["type"]=="dianzan"){

        $id = $arr["id"];

        $result = mysqli_query($conn,"update message set count=count+1 where id = '$id'");

    }

    

?>