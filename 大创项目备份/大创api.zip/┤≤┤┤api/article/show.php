<?php
function json_to_array(){	
		if(is_array($_POST)&&count($_POST)>0){
			return $_POST;
		}
		else{
			$json = file_get_contents('php://input');
			$arr =  json_decode($json,true);
			return $arr;
		}
	}
	$arr = json_to_array();
	$id = $arr["id"];	
	$data = array(); 
	$conn = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin","wx");
	if($id == "-1"){
		$sql = "select * from time_file where 1";
		$result=mysqli_query($conn,$sql);
		$data = mysqli_fetch_all($result);
	}
	else{
		$sql = "select * from time_file where id = '$id'";
		$result=mysqli_query($conn,$sql);
		$data = mysqli_fetch_array($result);
	}
	if($conn){
		echo json_encode(array("code"=>1,"data"=>$data,"msg"=>"select OK!"));
	}
	else{	
		echo json_encode(array("code"=>0,"data"=>$data,"msg"=>"select err!"));
	}
?>