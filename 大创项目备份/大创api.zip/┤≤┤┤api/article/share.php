<?php
	include('../mysql.php');
	$arr = json_to_array();
	print_r($arr);
	switch($arr['type']){
		case "insert":
			echo"insert";
			$usr_id = $arr['usr_id'];
			$context = $arr['context'];
			$text = $arr['text'];
			$date = $arr['date'];
			$title = $arr['title'];
			$label1 = $arr['label1'];
			$label2 = $arr['label2'];
			$label3 = $arr['label3'];
			$sql = "insert into share (usr_id, context, text, title, date, label1, label2, label3)values('$usr_id', '$context', '$text',
			'$title', '$date', '$label1', '$label2', '$label3')";
			echo $sql;
			$result = mysqli_query($conn, $sql);
			if($result){
				echo json_encode(array("code"=>0, "data"=>"", "msg"=>"insert success"));
			}
			else{
				echo json_encode(array("code"=>1, "data"=>"", "msg"=>"insert error"));
			}
		case "select_all":
			echo "select_all";
			$sql = "select * from share where 1";
			$result = mysqli_query($conn, $sql);
			$data = mysqli_fetch_all($result);
			if($result){
				echo json_encode(array("code"=>0, "data"=>$data, "msg"=>"select success"));
			}
			else{
				echo json_encode(array("code"=>1, "data"=>"", "msg"=>"select fail"));
			}
	}
	




?>