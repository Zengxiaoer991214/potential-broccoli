<?php
//	header('Content-Type:application/json');  
	function json_to_array(){	
		if(is_array($_POST)&&count($_POST)>0){
			return $_POST;
		}
		else{
			$json = file_get_contents('php://input');
			$arr =  json_decode($json,true);
			return $arr;
		}
	}
	$arr = json_to_array();
	$context = $arr["context"];
	$text = $arr["text"];
//	echo $arr['context'];
	$conn = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin","wx");
	$sql = "INSERT INTO time_file (article, text) VALUES ('$context', '$text')";
	$b=mysqli_query($conn,$sql);
	if($conn){
		echo json_encode(array("code"=>1,"data"=>"","msg"=>"insert OK!"));
	}
	else{	
		echo json_encode(array("code"=>0,"data"=>"","msg"=>"insert err!"));
	}
?>