<?php
	function json_to_array(){	
		if(is_array($_POST)&&count($_POST)>0){
			return $_POST;
		}
		else{
			$json = file_get_contents('php://input');
			$arr =  json_decode($json,true);
			return $arr;
		}
	}
	
	$conn = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin","wx");
	if(!$conn){
		echo"mysql_error";
		echo mysqli_error($conn);
	}


?>