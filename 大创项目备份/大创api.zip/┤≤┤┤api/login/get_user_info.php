<?php
function json_to_array(){	
		if(is_array($_POST)&&count($_POST)>0){
			return $_POST;
		}
		else{
			$json = file_get_contents('php://input');
			$arr =  json_decode($json,true);
			return $arr;
		}
	}
$arr = json_to_array();

$conn = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin",'wx');

$openid = $arr['openid'];
$session_key =$arr['session_key'];
$arr = [];
if($openid&&$session_key){
	$sql = "select * from user_info where u_i_openid = $openid";
	$result = mysqli_query($conn,$sql);
	$row = mysqli_fetch_array($result);
	//$arr=array("u_i_id"=>$row['u_i_id']);
	if(!$row){
		$code = "1";
		$msg = "查无此账号,已经新建账号";
		$sql2 = "insert into user_info (u_i_openid, u_i_session_key, u_i_nickname)values('$openid',$session_key,'未设置昵称')";
		$res = mysqli_query($conn, $sql2);
		if($res){
			$sql = "select * from user_info where u_i_openid = '$openid' AND u_i_session_key = '$session_key'";
			$result = mysqli_query($conn,$sql);
			$row = mysqli_fetch_array($result);
			$arr = array("id"=>$row['u_i_id'],"nick_name"=>'未设置昵称');	
		}
		else{
			echo (json_encode(array("code"=>3,"data"=>"","msg"=>"后台错误，请重试")));
			return;
		}
		
	}
	elseif($row['u_i_session_key' ] == $session_key){
		$code = "0";
		$arr = array("id"=>$row['u_i_id'],"nick_name"=>$row['u_i_nickname']);
		$msg = '';
	}
	else{
		$code = '2';
		$msg = "密码错误";
	}
	$sum_arr=array("code"=>$code,"data"=>$arr,"msg"=>$msg);
	echo (json_encode($sum_arr));
}
?>