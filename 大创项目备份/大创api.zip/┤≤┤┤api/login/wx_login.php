<?php
	header('Content-Type:application/json');  
	$conn = mysqli_connect("aaaaaaaaaa.mysql.cn-chengdu.rds.aliyuncs.com","zengrui","991214Lilin","wx");
	function receive_json_to_array(){
		$json = file_get_contents('php://input');
		$arr =  json_decode($json, true);
		return $arr;
	}
//	function get_time($conn,$id){
//		$sql = "select * from time_msg where t_m_u_i_id = $id order by t_m_id and t_m_doing = 1 and t_m_isend= 0";
//		$timeTodo = [];
//
//		$index =0;
//
//		$re = mysqli_query($conn, $sql);
//
//		while($item = mysqli_fetch_array($re)){
//
//			$time_arr = array("id"=>$index, 
//
//							  "u_id"=>$id, 
//
//							  "t_id"=>$item['t_m_id'],
//
//							  "title"=>$item['t_m_title'], 
//
//							  "time"=>$item['t_m_time'], 
//
//							  "color"=>$item['t_m_color'],
//
//							  "do_count"=>$item['t_m_do_count'],
//
//							  "time_count"=>$item['t_m_time_count'],
//
//							 );
//
//			array_push($timeTodo, $time_arr);
//
//			$index++;
//
//		}
//
//		return($timeTodo);
//
//	}
	$arr = receive_json_to_array();
	$codex = $arr['code'];
	$appid = "wx85b9eae0a17bb36e";
	$secret = "5826f1add2392e52c52d394cd578c658";
	$grant_type = "authorization_code";
	$url = "https://api.weixin.qq.com/sns/jscode2session?appid=$appid&secret=$secret&js_code=$codex&grant_type=authorization_code";
	function geturl($url){
        $headerArray =array("Content-type:application/json;","Accept:application/json");
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch,CURLOPT_HTTPHEADER,$headerArray);
        $output = curl_exec($ch);
        curl_close($ch);
        $output = json_decode($output,true);
        return $output;
	}	
	

	$arr = geturl("$url");
	$openid = $arr['openid'];
	$session_key = $arr['session_key'];

	$result = mysqli_query($conn,"select * from user_info where u_i_openid = '$openid'");
	$row = mysqli_fetch_all($result, MYSQLI_ASSOC);
//	print_r($row);
	if(mysqli_num_rows($result) < 1){
		$code = 0;
		$msg = "查无此账号,已经新建账号";
		$sql2 = "insert into user_info (u_i_openid, u_i_session_key)values('$openid','$session_key')";
		$res = mysqli_query($conn, $sql2);
		if($res){
			$sql = "select * from user_info where u_i_openid = '$openid' AND u_i_session_key = '$session_key'";
			$result = mysqli_query($conn,$sql);
			$row = mysqli_fetch_all($result, MYSQLI_ASSOC);
			$arr3 = $row[0];
//			$arr4 = get_time($conn,$row['u_i_id']);
			$arr4 = null;
			$arr2 = array("user_info"=>$arr3,"timeTodo"=>$arr4);

		}
		else{
			echo (json_encode(array("code"=>3,"data"=>"","msg"=>"后台错误，请重试")));
			return;
		}
	}
	else{
		$code = "0";
		$arr3 = $row[0];
		$msg = '';
//		$arr4 = get_time($conn,$row['u_i_id']);
		$arr4 = null;
		$arr2 = array("user_info"=>$arr3,"timeTodo"=>$arr4);
	}
	$sum_arr=array("code"=>$code,"data"=>$arr2,"msg"=>$msg);
	echo (json_encode($sum_arr));

?>